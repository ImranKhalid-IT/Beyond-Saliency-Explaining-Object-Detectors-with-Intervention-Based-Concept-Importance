$ErrorActionPreference = "Stop"
if (-not $env:CAUSAL_LAB_ACCESS_TOKEN) { throw "CAUSAL_LAB_ACCESS_TOKEN is not set" }
.\.venv\Scripts\python.exe -m causal_lab.cli compare
