from causal_lab.utils.geometry import box_area, calculate_iou

def test_box_area():
    assert box_area([0, 0, 10, 5]) == 50

def test_iou_identity():
    assert calculate_iou([0, 0, 10, 10], [0, 0, 10, 10]) > 0.999999
