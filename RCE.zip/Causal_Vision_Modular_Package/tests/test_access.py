import os
import pytest
from causal_lab.access import AccessDenied, verify_access

def test_missing_token_is_denied(monkeypatch):
    monkeypatch.delenv("CAUSAL_LAB_ACCESS_TOKEN", raising=False)
    with pytest.raises(AccessDenied):
        verify_access()
