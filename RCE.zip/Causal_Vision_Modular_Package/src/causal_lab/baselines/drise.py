from __future__ import annotations

from typing import Iterable, Tuple
import math
import cv2
import numpy as np
import torch
from PIL import Image
from tqdm.auto import tqdm
from ..config import DRISE_BATCH_SIZE, DRISE_GRID_SIZE, DRISE_KEEP_PROBABILITY, DRISE_MASK_COUNT, SEED
from ..models.yolov5 import YOLOv5Processor
from ..schemas import Detection
from .common import detect_batch, matched_detection_similarity, normalize01

def random_drise_masks(
    count: int,
    height: int,
    width: int,
    grid_size: int = DRISE_GRID_SIZE,
    keep_probability: float = DRISE_KEEP_PROBABILITY,
    seed: int = SEED,
) -> Iterable[np.ndarray]:
    """Generate RISE/D-RISE masks using a coarse Bernoulli grid and random shift."""
    rng = np.random.default_rng(seed)
    cell_h = int(math.ceil(height / grid_size))
    cell_w = int(math.ceil(width / grid_size))
    up_h = (grid_size + 1) * cell_h
    up_w = (grid_size + 1) * cell_w
    for _ in range(count):
        coarse = (rng.random((grid_size, grid_size)) < keep_probability).astype(np.float32)
        upsampled = cv2.resize(coarse, (up_w, up_h), interpolation=cv2.INTER_LINEAR)
        shift_y = int(rng.integers(0, cell_h))
        shift_x = int(rng.integers(0, cell_w))
        yield upsampled[shift_y : shift_y + height, shift_x : shift_x + width]


def drise_pair_maps(
    processor: YOLOv5Processor,
    image: Image.Image,
    detection_a: Detection,
    detection_b: Detection,
    mask_count: int = DRISE_MASK_COUNT,
    batch_size: int = DRISE_BATCH_SIZE,
) -> Tuple[np.ndarray, np.ndarray]:
    """Create two independent D-RISE maps while sharing the same random masks."""
    image_rgb = np.asarray(image.convert("RGB"), dtype=np.float32)
    height, width = image_rgb.shape[:2]
    saliency_a = np.zeros((height, width), dtype=np.float64)
    saliency_b = np.zeros((height, width), dtype=np.float64)
    masks = list(random_drise_masks(mask_count, height, width))

    for start in tqdm(range(0, mask_count, batch_size), desc="D-RISE masks", leave=False):
        batch_masks = masks[start : start + batch_size]
        masked_images = [
            Image.fromarray(np.uint8(np.clip(image_rgb * mask[..., None], 0, 255)))
            for mask in batch_masks
        ]
        batch_detections = detect_batch(processor, masked_images)
        for mask, detections in zip(batch_masks, batch_detections):
            saliency_a += matched_detection_similarity(detections, detection_a) * mask
            saliency_b += matched_detection_similarity(detections, detection_b) * mask

    denominator = float(mask_count) * float(DRISE_KEEP_PROBABILITY) + 1e-8
    return normalize01(saliency_a / denominator), normalize01(saliency_b / denominator)
