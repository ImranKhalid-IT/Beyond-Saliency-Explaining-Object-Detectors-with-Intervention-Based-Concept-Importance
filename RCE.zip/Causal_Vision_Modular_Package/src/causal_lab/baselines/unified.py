from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple
import gc
import time
import matplotlib.pyplot as plt
import numpy as np
import torch
from PIL import Image
from ..config import SAVE_PDF, SHOW_TOP_CONCEPTS
from ..models.yolov5 import YOLOv5Processor
from ..schemas import ConceptResult, Detection, LetterboxMeta, UnifiedBaselineResult
from ..visualization.relational import combined_top_concept_heatmap, draw_labelled_box, make_union_overlay, overlay_heatmap
from .craft import craft_object_concepts
from .drise import drise_pair_maps
from .gradient import YOLOv5GradientAdapter

def compute_unified_baselines(
    processor: YOLOv5Processor,
    image: Image.Image,
    detection_a: Detection,
    detection_b: Detection,
    feature_tensor: torch.Tensor,
    feature_meta: LetterboxMeta,
) -> UnifiedBaselineResult:
    maps: Dict[str, np.ndarray] = {}
    metadata: Dict[str, Any] = {}
    runtimes: Dict[str, float] = {}

    start = time.perf_counter()
    maps["drise_a"], maps["drise_b"] = drise_pair_maps(
        processor, image, detection_a, detection_b
    )
    runtimes["D-RISE"] = time.perf_counter() - start

    gradient_adapter = YOLOv5GradientAdapter(processor)

    start = time.perf_counter()
    maps["odam_a"], metadata["odam_a"] = gradient_adapter.odam(image, detection_a)
    maps["odam_b"], metadata["odam_b"] = gradient_adapter.odam(image, detection_b)
    runtimes["ODAM"] = time.perf_counter() - start
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    start = time.perf_counter()
    maps["finer_a"], metadata["finer_a"] = gradient_adapter.finer_cam(image, detection_a)
    maps["finer_b"], metadata["finer_b"] = gradient_adapter.finer_cam(image, detection_b)
    runtimes["Finer-CAM"] = time.perf_counter() - start
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    start = time.perf_counter()
    maps["craft_a"], craft_a = craft_object_concepts(
        processor, image, detection_a, feature_tensor, feature_meta
    )
    maps["craft_b"], craft_b = craft_object_concepts(
        processor, image, detection_b, feature_tensor, feature_meta
    )
    runtimes["CRAFT-adapted"] = time.perf_counter() - start
    metadata["craft_a"] = [
        {
            "concept": concept.concept_index + 1,
            "importance": concept.importance,
            "activation_mass": concept.activation_mass,
        }
        for concept in craft_a
    ]
    metadata["craft_b"] = [
        {
            "concept": concept.concept_index + 1,
            "importance": concept.importance,
            "activation_mass": concept.activation_mass,
        }
        for concept in craft_b
    ]

    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return UnifiedBaselineResult(maps=maps, metadata=metadata, runtimes=runtimes)


def save_map_arrays(maps: Dict[str, np.ndarray], destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for name, values in maps.items():
        np.save(destination / f"{name}.npy", np.asarray(values, dtype=np.float32))


def create_unified_comparison_figure(
    image: Image.Image,
    image_id: int,
    detection_a: Detection,
    detection_b: Detection,
    pair_union: np.ndarray,
    baseline_result: UnifiedBaselineResult,
    rce_concepts: Sequence[ConceptResult],
    output_stem: Path,
) -> Path:
    image_rgb = np.asarray(image.convert("RGB"))
    boxed = image_rgb.copy()
    draw_labelled_box(boxed, detection_a, (0, 255, 255))
    draw_labelled_box(boxed, detection_b, (255, 255, 0))
    union_view = make_union_overlay(image_rgb, pair_union)
    rce_map = combined_top_concept_heatmap(rce_concepts, pair_union, image.size, top_n=3)

    maps = baseline_result.maps
    fig, axes = plt.subplots(2, 6, figsize=(24, 9.2))
    fig.suptitle(
        f"Unified XAI Baseline Comparison — {detection_a.class_name} + "
        f"{detection_b.class_name} | COCO {image_id}",
        fontsize=18,
        fontweight="bold",
    )

    axes[0, 0].imshow(boxed)
    axes[0, 0].set_title("Target object pair", fontweight="bold")
    axes[1, 0].imshow(union_view)
    axes[1, 0].set_title("RCE relational union", fontweight="bold")

    panel_specs = [
        (1, "D-RISE", "drise_a", "drise_b"),
        (2, "ODAM", "odam_a", "odam_b"),
        (3, "Finer-CAM", "finer_a", "finer_b"),
        (4, "CRAFT-adapted", "craft_a", "craft_b"),
    ]
    for column, method, key_a, key_b in panel_specs:
        axes[0, column].imshow(overlay_heatmap(image_rgb, maps[key_a]))
        axes[0, column].set_title(
            f"{method}: {detection_a.class_name}", fontweight="bold"
        )
        axes[1, column].imshow(overlay_heatmap(image_rgb, maps[key_b]))
        axes[1, column].set_title(
            f"{method}: {detection_b.class_name}", fontweight="bold"
        )

    axes[0, 5].imshow(overlay_heatmap(image_rgb, rce_map))
    axes[0, 5].set_title("RCE: relational concepts", fontweight="bold")

    ranked = sorted(rce_concepts, key=lambda result: result.effect_score, reverse=True)
    displayed = ranked[: min(SHOW_TOP_CONCEPTS, len(ranked))]
    labels = [f"C{item.concept_index + 1}: {item.auto_region_label}" for item in displayed]
    scores = [item.effect_score for item in displayed]
    positions = np.arange(len(labels))
    axes[1, 5].barh(positions, scores, edgecolor="black", linewidth=0.8)
    axes[1, 5].set_yticks(positions)
    axes[1, 5].set_yticklabels(labels, fontsize=8)
    axes[1, 5].invert_yaxis()
    axes[1, 5].set_xlabel(r"Joint concept effect $CE_k=\min(\Delta s_A,\Delta s_B)$")
    axes[1, 5].set_title("RCE: joint intervention ranking", fontweight="bold")
    axes[1, 5].grid(axis="x", linestyle=":", alpha=0.35)

    for axis in axes.flat:
        if axis is not axes[1, 5]:
            axis.axis("off")

    fig.text(
        0.5,
        0.012,
        "D-RISE, ODAM and Finer-CAM explain each detection independently; "
        "CRAFT discovers object-conditioned concepts; RCE discovers concepts in the "
        "pair union and ranks their joint causal influence on both detections.",
        ha="center",
        fontsize=11,
    )
    plt.tight_layout(rect=[0.0, 0.04, 1.0, 0.95])
    png_path = output_stem.with_suffix(".png")
    fig.savefig(png_path, dpi=300, bbox_inches="tight")
    if SAVE_PDF:
        fig.savefig(output_stem.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)
    return png_path
