from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Tuple
import cv2
import numpy as np
import torch
import torch.nn.functional as F
import torchvision
from PIL import Image
from ..config import FINER_ALPHA, FINER_REFERENCE_COUNT
from ..models.yolov5 import YOLOv5Processor, _collect_4d_tensors
from ..schemas import Detection, LetterboxMeta
from ..utils.geometry import feature_map_to_original, letterbox_rgb
from .common import normalize01

def _find_prediction_tensor(value: Any) -> Optional[torch.Tensor]:
    if torch.is_tensor(value) and value.ndim == 3 and value.shape[-1] >= 6:
        return value
    if isinstance(value, (list, tuple)):
        for item in value:
            found = _find_prediction_tensor(item)
            if found is not None:
                return found
    if isinstance(value, dict):
        for item in value.values():
            found = _find_prediction_tensor(item)
            if found is not None:
                return found
    return None


def xywh_tensor_to_xyxy(boxes: torch.Tensor) -> torch.Tensor:
    x, y, w, h = boxes.unbind(dim=-1)
    return torch.stack((x - w / 2, y - h / 2, x + w / 2, y + h / 2), dim=-1)


def map_box_to_letterbox_tensor(box: np.ndarray, meta: LetterboxMeta, device: torch.device) -> torch.Tensor:
    transformed = torch.tensor(
        [
            box[0] * meta.ratio + meta.left,
            box[1] * meta.ratio + meta.top,
            box[2] * meta.ratio + meta.left,
            box[3] * meta.ratio + meta.top,
        ],
        dtype=torch.float32,
        device=device,
    )
    return transformed


class YOLOv5GradientAdapter:
    """Gradient bridge for ODAM and Finer-CAM on the same YOLOv5x6 detector."""

    def __init__(self, processor: YOLOv5Processor) -> None:
        self.processor = processor
        self.backend = processor.backend
        self.detect_layer = processor.detect_layer

    def _prepare(self, image: Image.Image) -> Tuple[torch.Tensor, LetterboxMeta]:
        image_rgb = np.asarray(image.convert("RGB"))
        padded, meta = letterbox_rgb(
            image_rgb, new_shape=(self.processor.input_size, self.processor.input_size)
        )
        tensor = (
            torch.from_numpy(padded)
            .to(self.processor.device)
            .permute(2, 0, 1)
            .contiguous()
            .unsqueeze(0)
            .float()
            / 255.0
        )
        if getattr(self.backend, "fp16", False):
            tensor = tensor.half()
        tensor.requires_grad_(True)
        return tensor, meta

    def _forward(self, image: Image.Image) -> Tuple[torch.Tensor, List[torch.Tensor], LetterboxMeta]:
        tensor, meta = self._prepare(image)
        captured: List[torch.Tensor] = []

        def capture_inputs(module: torch.nn.Module, inputs: Tuple[Any, ...]) -> None:
            tensors: List[torch.Tensor] = []
            _collect_4d_tensors(inputs, tensors)
            captured.extend(tensors)
            for feature in tensors:
                if feature.requires_grad:
                    feature.retain_grad()

        handle = self.detect_layer.register_forward_pre_hook(capture_inputs)
        try:
            output = self.backend(tensor, augment=False, visualize=False)
        finally:
            handle.remove()
        prediction = _find_prediction_tensor(output)
        if prediction is None:
            raise RuntimeError("Could not locate YOLOv5 raw prediction tensor.")
        if not captured:
            raise RuntimeError("Could not capture YOLOv5 multi-scale detector features.")
        return prediction, captured, meta

    def _select_anchor(
        self,
        prediction: torch.Tensor,
        target: Detection,
        meta: LetterboxMeta,
    ) -> Tuple[int, torch.Tensor, torch.Tensor]:
        candidates = prediction[0]
        class_index = 5 + int(target.label_idx)
        if class_index >= candidates.shape[1]:
            raise IndexError(f"Class index {target.label_idx} is outside prediction tensor.")
        boxes = xywh_tensor_to_xyxy(candidates[:, :4].float())
        target_box = map_box_to_letterbox_tensor(
            target.box_xyxy, meta, candidates.device
        ).unsqueeze(0)
        overlaps = torchvision.ops.box_iou(target_box, boxes)[0]
        class_score = candidates[:, 4].float() * candidates[:, class_index].float()
        quality = overlaps * class_score
        selected_index = int(torch.argmax(quality).item())
        return selected_index, overlaps[selected_index], class_score[selected_index]

    def _aggregate_feature_maps(
        self,
        features: Sequence[torch.Tensor],
        meta: LetterboxMeta,
        method: str,
    ) -> np.ndarray:
        maps: List[np.ndarray] = []
        for feature in features:
            gradient = feature.grad
            if gradient is None:
                continue
            activation = feature.float()
            gradient = gradient.float()
            if float(gradient.detach().abs().sum()) <= 1e-12:
                continue
            if method == "odam":
                local_map = torch.relu((activation * gradient).sum(dim=1))[0]
            elif method == "finer_cam":
                weights = gradient.mean(dim=(2, 3), keepdim=True)
                local_map = torch.relu((activation * weights).sum(dim=1))[0]
            else:
                raise ValueError(f"Unknown gradient map method: {method}")
            original_map = feature_map_to_original(
                local_map.detach().cpu().numpy(), meta
            )
            maps.append(normalize01(original_map))
        if not maps:
            original_w, original_h = meta.original_size
            return np.zeros((original_h, original_w), dtype=np.float32)
        stacked = np.stack(maps, axis=0)
        merged = np.max(stacked, axis=0)
        merged = cv2.GaussianBlur(merged, (0, 0), sigmaX=1.2)
        return normalize01(merged)

    def odam(self, image: Image.Image, target: Detection) -> Tuple[np.ndarray, Dict[str, Any]]:
        self.backend.zero_grad(set_to_none=True)
        prediction, features, meta = self._forward(image)
        index, overlap, anchor_score = self._select_anchor(prediction, target, meta)
        selected = prediction[0, index]
        objective = selected[4].float() * selected[5 + target.label_idx].float()
        objective.backward(retain_graph=False)
        heatmap = self._aggregate_feature_maps(features, meta, method="odam")
        return heatmap, {
            "selected_anchor": index,
            "anchor_iou": float(overlap.detach().cpu()),
            "anchor_class_score": float(anchor_score.detach().cpu()),
        }

    def finer_cam(
        self,
        image: Image.Image,
        target: Detection,
        alpha: float = FINER_ALPHA,
        reference_count: int = FINER_REFERENCE_COUNT,
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        self.backend.zero_grad(set_to_none=True)
        prediction, features, meta = self._forward(image)
        index, overlap, anchor_score = self._select_anchor(prediction, target, meta)
        selected = prediction[0, index]
        class_probabilities = selected[5:].float().clamp(1e-6, 1.0 - 1e-6)
        class_logits = torch.logit(class_probabilities)
        main_index = int(target.label_idx)
        differences = torch.abs(class_logits - class_logits[main_index])
        differences[main_index] = torch.inf
        references = torch.argsort(differences)[:reference_count]
        reference_weights = torch.softmax(class_logits[references], dim=0)
        relative_objective = (
            reference_weights
            * (class_logits[main_index] - float(alpha) * class_logits[references])
        ).sum() / (reference_weights.sum() + 1e-9)
        objective = selected[4].float() * relative_objective
        objective.backward(retain_graph=False)
        heatmap = self._aggregate_feature_maps(features, meta, method="finer_cam")
        reference_names = [
            str(self.processor.detector.names[int(index_value)])
            for index_value in references.detach().cpu().tolist()
        ]
        return heatmap, {
            "selected_anchor": index,
            "anchor_iou": float(overlap.detach().cpu()),
            "anchor_class_score": float(anchor_score.detach().cpu()),
            "reference_classes": reference_names,
        }
