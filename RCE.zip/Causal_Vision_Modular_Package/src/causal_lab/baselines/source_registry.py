from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Dict
from ..config import BASELINE_ROOT, SOURCE_REPOSITORIES

def clone_public_sources(destination: Path = Path("/content/public_xai_sources")) -> Dict[str, str]:
    """Clone public reference repositories and return their commit hashes.

    The unified adapters are self-contained so that a temporary GitHub outage does
    not invalidate an already-open Colab runtime. Cloning records exact provenance.
    """
    destination.mkdir(parents=True, exist_ok=True)
    commits: Dict[str, str] = {}
    for name, url in SOURCE_REPOSITORIES.items():
        repo_dir = destination / name.replace("/", "_")
        if not repo_dir.exists():
            completed = subprocess.run(
                ["git", "clone", "--depth", "1", url, str(repo_dir)],
                text=True,
                capture_output=True,
            )
            if completed.returncode != 0:
                print(f"[Source warning] {name} clone failed: {completed.stderr.strip()}")
                commits[name] = "clone_failed"
                continue
        completed = subprocess.run(
            ["git", "-C", str(repo_dir), "rev-parse", "HEAD"],
            text=True,
            capture_output=True,
        )
        commits[name] = (
            completed.stdout.strip() if completed.returncode == 0 else "unknown"
        )
    with open(BASELINE_ROOT / "source_commits.json", "w", encoding="utf-8") as file:
        json.dump({"repositories": SOURCE_REPOSITORIES, "commits": commits}, file, indent=2)
    return commits
