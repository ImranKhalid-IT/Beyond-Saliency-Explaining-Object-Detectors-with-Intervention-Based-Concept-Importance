from __future__ import annotations

from typing import List, Optional, Sequence, Tuple
import numpy as np
import torch
from PIL import Image
from ..config import BASELINE_MATCH_IOU, INTERVENTION_DETECTION_CONF
from ..models.yolov5 import YOLOv5Processor
from ..schemas import Detection
from ..utils.geometry import calculate_iou

def normalize01(values: np.ndarray, support: Optional[np.ndarray] = None) -> np.ndarray:
    values = np.asarray(values, dtype=np.float32)
    result = np.zeros_like(values, dtype=np.float32)
    if support is None:
        valid = np.isfinite(values)
    else:
        valid = (np.asarray(support) > 0) & np.isfinite(values)
    if not np.any(valid):
        return result
    lo = float(values[valid].min())
    hi = float(values[valid].max())
    if hi - lo <= 1e-8:
        return result
    result[valid] = (values[valid] - lo) / (hi - lo)
    return result


def matched_detection_score(
    detections: Sequence[Detection],
    target: Detection,
    minimum_iou: float = BASELINE_MATCH_IOU,
) -> float:
    best = 0.0
    for detection in detections:
        if detection.label_idx != target.label_idx:
            continue
        overlap = calculate_iou(target.box_xyxy, detection.box_xyxy)
        if overlap >= minimum_iou:
            best = max(best, float(detection.score))
    return best


def matched_detection_similarity(
    detections: Sequence[Detection], target: Detection
) -> float:
    """D-RISE localization × categorization similarity.

    YOLOv5 post-NMS outputs expose the predicted class confidence rather than the
    full class vector. The category similarity therefore becomes target-class
    confidence for detections of the same class, multiplied by box IoU.
    """
    best = 0.0
    for detection in detections:
        if detection.label_idx != target.label_idx:
            continue
        overlap = calculate_iou(target.box_xyxy, detection.box_xyxy)
        best = max(best, overlap * float(detection.score))
    return best


def detect_batch(
    processor: YOLOv5Processor,
    images: Sequence[Image.Image],
    confidence: float = INTERVENTION_DETECTION_CONF,
) -> List[List[Detection]]:
    old_conf = float(processor.detector.conf)
    processor.detector.conf = float(confidence)
    try:
        with torch.no_grad():
            results = processor.detector(list(images), size=processor.input_size)
        frames = results.pandas().xyxy
        all_detections: List[List[Detection]] = []
        for frame in frames:
            detections: List[Detection] = []
            for _, row in frame.iterrows():
                label_idx = int(row["class"])
                detections.append(
                    Detection(
                        box_xyxy=np.array(
                            [row.xmin, row.ymin, row.xmax, row.ymax],
                            dtype=np.float32,
                        ),
                        score=float(row.confidence),
                        label_idx=label_idx,
                        class_name=str(processor.detector.names[label_idx]),
                    )
                )
            all_detections.append(detections)
        return all_detections
    finally:
        processor.detector.conf = old_conf
