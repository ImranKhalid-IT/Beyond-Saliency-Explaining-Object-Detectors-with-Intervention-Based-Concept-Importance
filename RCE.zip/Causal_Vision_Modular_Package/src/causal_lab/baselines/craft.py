from __future__ import annotations

from typing import List, Tuple
import cv2
import numpy as np
import torch
from PIL import Image, ImageFilter
from sklearn.decomposition import NMF
from ..config import ACTIVATION_PERCENTILE, BLUR_RADIUS, CRAFT_CONCEPTS, CRAFT_EVALUATED_CONCEPTS, INTERVENTION_DETECTION_CONF, SEED
from ..models.yolov5 import YOLOv5Processor
from ..schemas import CraftConcept, Detection, LetterboxMeta
from ..utils.geometry import box_mask, feature_map_to_original, map_box_to_feature
from .common import matched_detection_score, normalize01

def craft_object_concepts(
    processor: YOLOv5Processor,
    image: Image.Image,
    target: Detection,
    feature_tensor: torch.Tensor,
    meta: LetterboxMeta,
    number_of_concepts: int = CRAFT_CONCEPTS,
    evaluated_concepts: int = CRAFT_EVALUATED_CONCEPTS,
) -> Tuple[np.ndarray, List[CraftConcept]]:
    """CRAFT-style NMF concepts for one object, without pair conditioning.

    CRAFT's official repository targets classifiers. This detector adapter keeps its
    non-negative matrix factorization concept core, then estimates object-specific
    importance by detector confidence drop after blurring a concept region. Unlike
    RCE, each object is explained independently and no joint pair score is used.
    """
    _, channels, feature_h, feature_w = feature_tensor.shape
    x1, y1, x2, y2 = map_box_to_feature(target.box_xyxy, meta, (feature_h, feature_w))
    if x2 <= x1 or y2 <= y1:
        return np.zeros((image.height, image.width), dtype=np.float32), []

    feature_grid = feature_tensor[0].permute(1, 2, 0).detach().float().cpu().numpy()
    feature_grid = np.clip(feature_grid, 0.0, None)
    region_vectors = feature_grid[y1:y2, x1:x2].reshape(-1, channels)
    valid = np.isfinite(region_vectors).all(axis=1)
    region_vectors = region_vectors[valid]
    if region_vectors.shape[0] < 2 or float(region_vectors.max()) <= 0.0:
        return np.zeros((image.height, image.width), dtype=np.float32), []

    component_count = max(
        1, min(int(number_of_concepts), region_vectors.shape[0], region_vectors.shape[1])
    )
    factorizer = NMF(
        n_components=component_count,
        init="nndsvda",
        random_state=SEED,
        max_iter=500,
    )
    factorizer.fit(region_vectors + 1e-8)
    all_vectors = feature_grid.reshape(-1, channels)
    concept_coefficients = factorizer.transform(all_vectors + 1e-8)
    concept_maps = concept_coefficients.reshape(feature_h, feature_w, component_count)

    object_support = box_mask(target.box_xyxy, image.size)
    candidates: List[Tuple[int, float, np.ndarray]] = []
    for concept_index in range(component_count):
        original_map = feature_map_to_original(concept_maps[..., concept_index], meta)
        normalized = normalize01(original_map, object_support)
        activation_mass = float((original_map * object_support).sum())
        candidates.append((concept_index, activation_mass, normalized))
    candidates.sort(key=lambda item: item[1], reverse=True)

    image_rgb = np.asarray(image.convert("RGB"))
    blurred = np.asarray(image.filter(ImageFilter.GaussianBlur(radius=BLUR_RADIUS)))
    concepts: List[CraftConcept] = []
    for concept_index, activation_mass, normalized in candidates[:evaluated_concepts]:
        values = normalized[object_support.astype(bool)]
        if values.size == 0 or float(values.max()) <= 0.0:
            importance = 0.0
        else:
            threshold = float(np.percentile(values, ACTIVATION_PERCENTILE))
            mask = ((normalized >= threshold) & (object_support > 0)).astype(np.uint8)
            counterfactual = np.where(mask[..., None] > 0, blurred, image_rgb).astype(np.uint8)
            detections = processor.detect(
                Image.fromarray(counterfactual),
                conf_threshold=INTERVENTION_DETECTION_CONF,
            )
            post_score = matched_detection_score(detections, target)
            importance = max(0.0, float(target.score) - post_score)
        concepts.append(
            CraftConcept(
                concept_index=int(concept_index),
                importance=float(importance),
                activation_mass=float(activation_mass),
                activation_map=normalized,
            )
        )

    if not concepts:
        return np.zeros((image.height, image.width), dtype=np.float32), []
    weights = np.array([concept.importance for concept in concepts], dtype=np.float32)
    if float(weights.sum()) <= 1e-8:
        weights = np.array([concept.activation_mass for concept in concepts], dtype=np.float32)
    weights = weights / (float(weights.sum()) + 1e-8)
    combined = np.zeros((image.height, image.width), dtype=np.float32)
    for weight, concept in zip(weights, concepts):
        combined += float(weight) * concept.activation_map
    return normalize01(combined, object_support), concepts
