from __future__ import annotations

from typing import Any, List, Optional, Sequence, Tuple
import numpy as np
import torch
from PIL import Image
from ..config import DEVICE, INITIAL_DETECTION_CONF, MATCH_IOU_THRESHOLD, MODEL_INPUT_SIZE, MODEL_NAME
from ..schemas import Detection, LetterboxMeta
from ..utils.geometry import calculate_iou, letterbox_rgb

def _collect_4d_tensors(value: Any, output: List[torch.Tensor]) -> None:
    if torch.is_tensor(value) and value.ndim == 4:
        output.append(value)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _collect_4d_tensors(item, output)
    elif isinstance(value, dict):
        for item in value.values():
            _collect_4d_tensors(item, output)


class YOLOv5Processor:
    """YOLOv5 detector plus a high-resolution neck feature capture."""

    def __init__(
        self,
        model_name: str = MODEL_NAME,
        device: str = DEVICE,
        input_size: int = MODEL_INPUT_SIZE,
    ) -> None:
        self.device = device
        self.input_size = int(input_size)
        print(f"Loading {model_name} on {device}...")
        self.detector = torch.hub.load(
            "ultralytics/yolov5",
            model_name,
            pretrained=True,
            trust_repo=True,
        )
        self.detector = self.detector.to(device).eval()
        self.detector.max_det = 300

        self.backend = self.detector.model
        try:
            self.detect_layer = self.backend.model.model[-1]
        except Exception as exc:
            raise RuntimeError(
                "Could not resolve the YOLOv5 Detect layer. "
                "The torch-hub model structure may have changed."
            ) from exc
        self._captured_feature: Optional[torch.Tensor] = None

    def _capture_detect_inputs(self, module: torch.nn.Module, inputs: Tuple[Any, ...]) -> None:
        tensors: List[torch.Tensor] = []
        _collect_4d_tensors(inputs, tensors)
        if not tensors:
            self._captured_feature = None
            return
        # Detect receives multi-scale neck maps. Use the highest spatial resolution.
        selected = max(tensors, key=lambda tensor: tensor.shape[-2] * tensor.shape[-1])
        self._captured_feature = selected.detach().clone()

    def detect(
        self,
        image: Image.Image,
        conf_threshold: float = INITIAL_DETECTION_CONF,
        iou_threshold: float = 0.45,
    ) -> List[Detection]:
        self.detector.conf = float(conf_threshold)
        self.detector.iou = float(iou_threshold)
        with torch.no_grad():
            results = self.detector(image, size=self.input_size)

        detections: List[Detection] = []
        dataframe = results.pandas().xyxy[0]
        for _, row in dataframe.iterrows():
            label_idx = int(row["class"])
            detections.append(
                Detection(
                    box_xyxy=np.array(
                        [row.xmin, row.ymin, row.xmax, row.ymax],
                        dtype=np.float32,
                    ),
                    score=float(row.confidence),
                    label_idx=label_idx,
                    class_name=str(self.detector.names[label_idx]),
                )
            )
        return detections

    def extract_features(
        self, image: Image.Image
    ) -> Tuple[torch.Tensor, LetterboxMeta]:
        image_rgb = np.asarray(image.convert("RGB"))
        padded, meta = letterbox_rgb(
            image_rgb, new_shape=(self.input_size, self.input_size)
        )
        tensor = (
            torch.from_numpy(padded)
            .to(self.device)
            .permute(2, 0, 1)
            .contiguous()
            .unsqueeze(0)
            .float()
            / 255.0
        )
        if getattr(self.backend, "fp16", False):
            tensor = tensor.half()

        self._captured_feature = None
        handle = self.detect_layer.register_forward_pre_hook(
            self._capture_detect_inputs
        )
        try:
            with torch.no_grad():
                _ = self.backend(tensor, augment=False, visualize=False)
        finally:
            handle.remove()

        if self._captured_feature is None:
            raise RuntimeError("YOLOv5 feature capture failed.")
        return self._captured_feature, meta


def match_detection_to_ground_truth(
    detections: Sequence[Detection],
    class_name: str,
    ground_truth_box: np.ndarray,
    minimum_iou: float = MATCH_IOU_THRESHOLD,
) -> Optional[Detection]:
    candidates: List[Tuple[float, float, Detection]] = []
    for detection in detections:
        if detection.class_name != class_name:
            continue
        iou = calculate_iou(detection.box_xyxy, ground_truth_box)
        candidates.append((iou, detection.score, detection))
    if not candidates:
        return None
    best_iou, _, best_detection = max(candidates, key=lambda item: (item[0], item[1]))
    return best_detection if best_iou >= minimum_iou else None
