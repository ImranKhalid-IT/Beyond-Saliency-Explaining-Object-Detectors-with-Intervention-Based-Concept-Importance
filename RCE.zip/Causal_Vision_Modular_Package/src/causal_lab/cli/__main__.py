from __future__ import annotations
import argparse
from ..access import verify_access

def main() -> None:
    parser = argparse.ArgumentParser(prog="causal-lab")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("relational")
    sub.add_parser("compare")
    one = sub.add_parser("single")
    one.add_argument("--image", default="data/example.jpg")
    args = parser.parse_args()
    verify_access()
    if args.command == "relational":
        from ..pipelines.relational import run_coco_generation
        run_coco_generation()
    elif args.command == "compare":
        from ..pipelines.comparison import run_full_baseline_comparison
        run_full_baseline_comparison()
    else:
        from pathlib import Path
        from ..single_image.runner import run
        run(Path(args.image))

if __name__ == "__main__":
    main()
