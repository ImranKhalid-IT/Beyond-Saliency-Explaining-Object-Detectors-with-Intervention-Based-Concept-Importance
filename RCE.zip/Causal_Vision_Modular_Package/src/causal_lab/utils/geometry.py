from __future__ import annotations

from typing import Optional, Sequence, Tuple
import math
import cv2
import numpy as np
import torch
from PIL import Image
from ..schemas import LetterboxMeta

def xywh_to_xyxy(box_xywh: Sequence[float]) -> np.ndarray:
    x, y, w, h = map(float, box_xywh)
    return np.array([x, y, x + w, y + h], dtype=np.float32)


def box_area(box: np.ndarray) -> float:
    return float(max(0.0, box[2] - box[0]) * max(0.0, box[3] - box[1]))


def union_box(box_a: np.ndarray, box_b: np.ndarray) -> np.ndarray:
    return np.array(
        [
            min(box_a[0], box_b[0]),
            min(box_a[1], box_b[1]),
            max(box_a[2], box_b[2]),
            max(box_a[3], box_b[3]),
        ],
        dtype=np.float32,
    )


def calculate_iou(box_a: np.ndarray, box_b: np.ndarray) -> float:
    x1 = max(float(box_a[0]), float(box_b[0]))
    y1 = max(float(box_a[1]), float(box_b[1]))
    x2 = min(float(box_a[2]), float(box_b[2]))
    y2 = min(float(box_a[3]), float(box_b[3]))
    intersection = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    union = box_area(box_a) + box_area(box_b) - intersection
    return intersection / (union + 1e-8)


def normalized_box_gap(
    box_a: np.ndarray, box_b: np.ndarray, width: int, height: int
) -> float:
    dx = max(float(box_a[0] - box_b[2]), float(box_b[0] - box_a[2]), 0.0)
    dy = max(float(box_a[1] - box_b[3]), float(box_b[1] - box_a[3]), 0.0)
    return math.hypot(dx, dy) / (math.hypot(width, height) + 1e-8)


def normalized_center_distance(
    box_a: np.ndarray, box_b: np.ndarray, width: int, height: int
) -> float:
    center_a = np.array(
        [(box_a[0] + box_a[2]) / 2.0, (box_a[1] + box_a[3]) / 2.0]
    )
    center_b = np.array(
        [(box_b[0] + box_b[2]) / 2.0, (box_b[1] + box_b[3]) / 2.0]
    )
    return float(np.linalg.norm(center_a - center_b)) / (
        math.hypot(width, height) + 1e-8
    )


def box_mask(box: np.ndarray, size: Tuple[int, int]) -> np.ndarray:
    width, height = size
    mask = np.zeros((height, width), dtype=np.uint8)
    x1, y1, x2, y2 = np.round(box).astype(int)
    x1, x2 = np.clip([x1, x2], 0, width)
    y1, y2 = np.clip([y1, y2], 0, height)
    if x2 > x1 and y2 > y1:
        mask[y1:y2, x1:x2] = 1
    return mask


def normalize_map(values: np.ndarray, support_mask: Optional[np.ndarray] = None) -> np.ndarray:
    values = np.asarray(values, dtype=np.float32)
    if support_mask is None:
        support = np.ones(values.shape, dtype=bool)
    else:
        support = support_mask.astype(bool)
    result = np.zeros_like(values, dtype=np.float32)
    valid = values[support]
    if valid.size == 0:
        return result
    lo, hi = float(valid.min()), float(valid.max())
    if hi - lo <= 1e-8:
        return result
    result[support] = (values[support] - lo) / (hi - lo)
    return result


def letterbox_rgb(
    image_rgb: np.ndarray,
    new_shape: Tuple[int, int] = (1280, 1280),
    color: Tuple[int, int, int] = (114, 114, 114),
) -> Tuple[np.ndarray, LetterboxMeta]:
    original_h, original_w = image_rgb.shape[:2]
    target_h, target_w = new_shape
    ratio = min(target_h / original_h, target_w / original_w)

    resized_w = int(round(original_w * ratio))
    resized_h = int(round(original_h * ratio))
    resized = cv2.resize(
        image_rgb, (resized_w, resized_h), interpolation=cv2.INTER_LINEAR
    )

    pad_w = target_w - resized_w
    pad_h = target_h - resized_h
    left = int(round(pad_w / 2.0 - 0.1))
    right = int(round(pad_w / 2.0 + 0.1))
    top = int(round(pad_h / 2.0 - 0.1))
    bottom = int(round(pad_h / 2.0 + 0.1))

    padded = cv2.copyMakeBorder(
        resized, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color
    )
    meta = LetterboxMeta(
        original_size=(original_w, original_h),
        input_size=(padded.shape[1], padded.shape[0]),
        resized_size=(resized_w, resized_h),
        ratio=ratio,
        left=left,
        top=top,
    )
    return padded, meta


def map_box_to_feature(
    box_original: np.ndarray, meta: LetterboxMeta, feature_hw: Tuple[int, int]
) -> Tuple[int, int, int, int]:
    feature_h, feature_w = feature_hw
    input_w, input_h = meta.input_size
    transformed = np.array(
        [
            box_original[0] * meta.ratio + meta.left,
            box_original[1] * meta.ratio + meta.top,
            box_original[2] * meta.ratio + meta.left,
            box_original[3] * meta.ratio + meta.top,
        ],
        dtype=np.float32,
    )
    x1 = int(np.floor(transformed[0] / input_w * feature_w))
    y1 = int(np.floor(transformed[1] / input_h * feature_h))
    x2 = int(np.ceil(transformed[2] / input_w * feature_w))
    y2 = int(np.ceil(transformed[3] / input_h * feature_h))
    x1, x2 = np.clip([x1, x2], 0, feature_w)
    y1, y2 = np.clip([y1, y2], 0, feature_h)
    return int(x1), int(y1), int(x2), int(y2)


def feature_map_to_original(
    feature_map: np.ndarray, meta: LetterboxMeta
) -> np.ndarray:
    input_w, input_h = meta.input_size
    resized_w, resized_h = meta.resized_size
    original_w, original_h = meta.original_size

    upsampled = cv2.resize(
        feature_map.astype(np.float32), (input_w, input_h), interpolation=cv2.INTER_LINEAR
    )
    crop = upsampled[
        meta.top : meta.top + resized_h,
        meta.left : meta.left + resized_w,
    ]
    if crop.size == 0:
        raise RuntimeError("Feature-map crop is empty; check letterbox metadata.")
    return cv2.resize(
        crop, (original_w, original_h), interpolation=cv2.INTER_LINEAR
    )
