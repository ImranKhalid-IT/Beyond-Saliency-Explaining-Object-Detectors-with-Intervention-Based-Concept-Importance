from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple
import cv2
import numpy as np
import torch
from PIL import Image, ImageFilter
from ..config import ACTIVATION_PERCENTILE, BLUR_RADIUS, INTERVENTION_DETECTION_CONF, MATCH_IOU_THRESHOLD, SAVE_COUNTERFACTUALS
from ..concepts.kmeans import automatic_region_label
from ..models.yolov5 import YOLOv5Processor
from ..schemas import ConceptResult, Detection, LetterboxMeta
from ..utils.geometry import box_mask, calculate_iou, feature_map_to_original, normalize_map

class RelationalInterventionExplainer:
    def __init__(
        self,
        processor: YOLOv5Processor,
        percentile: float = ACTIVATION_PERCENTILE,
        blur_radius: float = BLUR_RADIUS,
        matching_iou: float = MATCH_IOU_THRESHOLD,
    ) -> None:
        self.processor = processor
        self.percentile = float(percentile)
        self.blur_radius = float(blur_radius)
        self.matching_iou = float(matching_iou)

    def _matched_post_score(
        self,
        detections: Sequence[Detection],
        original_detection: Detection,
    ) -> float:
        candidates: List[Tuple[float, float]] = []
        for detection in detections:
            if detection.class_name != original_detection.class_name:
                continue
            iou = calculate_iou(
                original_detection.box_xyxy, detection.box_xyxy
            )
            if iou >= self.matching_iou:
                candidates.append((iou, detection.score))
        if not candidates:
            return 0.0
        return max(candidates, key=lambda item: (item[0], item[1]))[1]

    def evaluate(
        self,
        image: Image.Image,
        activation_maps: torch.Tensor,
        meta: LetterboxMeta,
        detection_a: Detection,
        detection_b: Detection,
        pair_union: np.ndarray,
        counterfactual_dir: Optional[Path] = None,
    ) -> List[ConceptResult]:
        image_rgb = np.asarray(image.convert("RGB"))
        width, height = image.size
        union_support = box_mask(pair_union, image.size)
        blurred = np.asarray(
            image.filter(ImageFilter.GaussianBlur(radius=self.blur_radius))
        )
        original_joint = detection_a.score * detection_b.score

        results: List[ConceptResult] = []
        for concept_index in range(activation_maps.shape[1]):
            feature_map = (
                activation_maps[0, concept_index].detach().cpu().numpy()
            )
            original_map = feature_map_to_original(feature_map, meta)
            normalized = normalize_map(original_map, union_support)

            values = normalized[union_support.astype(bool)]
            if values.size == 0 or float(values.max()) <= 0.0:
                threshold = 1.0
            else:
                threshold = float(np.percentile(values, self.percentile))

            intervention_mask = (
                (normalized >= threshold) & (union_support > 0)
            ).astype(np.uint8)
            mask_fraction = float(intervention_mask.sum()) / (
                float(union_support.sum()) + 1e-8
            )

            counterfactual = np.where(
                intervention_mask[..., None] > 0,
                blurred,
                image_rgb,
            ).astype(np.uint8)
            counterfactual_image = Image.fromarray(counterfactual)

            post_detections = self.processor.detect(
                counterfactual_image,
                conf_threshold=INTERVENTION_DETECTION_CONF,
            )
            post_a = self._matched_post_score(post_detections, detection_a)
            post_b = self._matched_post_score(post_detections, detection_b)

            # ہر آبجیکٹ کے سکور میں کتنی کمی آئی؟
            drop_a = max(0.0, float(detection_a.score) - post_a)
            drop_b = max(0.0, float(detection_b.score) - post_b)

            # XAI Correlation Metric: ہم min() استعمال کریں گے تاکہ صرف وہ حصہ
            # ٹاپ سکور حاصل کرے جو دونوں آبجیکٹس (Correlated) کو متاثر کرے۔
            effect = float(min(drop_a, drop_b))

            if counterfactual_dir is not None and SAVE_COUNTERFACTUALS:
                counterfactual_dir.mkdir(parents=True, exist_ok=True)
                counterfactual_image.save(
                    counterfactual_dir / f"concept_{concept_index + 1:02d}.png"
                )

            results.append(
                ConceptResult(
                    concept_index=concept_index,
                    effect_score=float(effect),
                    original_score_a=float(detection_a.score),
                    original_score_b=float(detection_b.score),
                    post_score_a=float(post_a),
                    post_score_b=float(post_b),
                    mask_fraction=float(mask_fraction),
                    auto_region_label=automatic_region_label(
                        normalized,
                        detection_a,
                        detection_b,
                        pair_union,
                    ),
                    activation_map=normalized,
                    intervention_mask=intervention_mask,
                )
            )
        return results
