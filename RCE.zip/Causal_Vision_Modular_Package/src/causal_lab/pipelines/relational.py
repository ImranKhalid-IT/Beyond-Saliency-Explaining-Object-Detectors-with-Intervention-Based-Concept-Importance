from __future__ import annotations

import json
import random
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional
import pandas as pd
from PIL import Image
from tqdm.auto import tqdm
from ..config import *
from ..concepts.kmeans import KMeansConceptExplainer
from ..data.coco import COCOPairSelector, ensure_coco_files
from ..interventions.relational import RelationalInterventionExplainer
from ..models.yolov5 import YOLOv5Processor, match_detection_to_ground_truth
from ..schemas import GroundTruthPair
from ..utils.geometry import box_area, union_box
from ..visualization.relational import create_contact_sheet, create_dashboard

def analyze_ground_truth_pair(
    processor: YOLOv5Processor,
    pair: GroundTruthPair,
    selector: COCOPairSelector,
) -> Optional[Dict[str, Any]]:
    image_path = selector.image_path(pair)
    if not image_path.exists():
        return None

    image = Image.open(image_path).convert("RGB")
    img_width, img_height = image.size
    img_area = img_width * img_height

    detections = processor.detect(
        image, conf_threshold=INITIAL_DETECTION_CONF
    )

    detection_a = match_detection_to_ground_truth(
        detections, pair.object_a, pair.box_a, minimum_iou=MATCH_IOU_THRESHOLD
    )
    detection_b = match_detection_to_ground_truth(
        detections, pair.object_b, pair.box_b, minimum_iou=MATCH_IOU_THRESHOLD
    )

    if detection_a is None or detection_b is None:
        return None

    # ==============================================================
    # NAYA IZAFA: Object Size Check (صرف بڑے اور سامنے والے آبجیکٹس کے لیے)
    # ==============================================================
    area_a = box_area(detection_a.box_xyxy)
    area_b = box_area(detection_b.box_xyxy)

    # اگر کوئی بھی آبجیکٹ پوری تصویر کے 4% یا 3% سے چھوٹا ہے، تو اسے چھوڑ دیں
    if area_a < (img_area * 0.04) or area_b < (img_area * 0.03):
        print(f"\n[Skipped] Image {pair.image_id} - Objects are too small (Background).")
        return None
    # ==============================================================

    pair_union = union_box(
        detection_a.box_xyxy, detection_b.box_xyxy
    )
    features, meta = processor.extract_features(image)
    concept_explainer = KMeansConceptExplainer()
    activation_maps = concept_explainer.discover(
        features, pair_union, meta
    )

    intervention_explainer = RelationalInterventionExplainer(processor, matching_iou=MATCH_IOU_THRESHOLD)
    example_stem = (
        f"coco_{pair.image_id}_"
        f"{pair.object_a.replace(' ', '_')}_"
        f"{pair.object_b.replace(' ', '_')}"
    )
    example_dir = OUTPUT_DIR / example_stem
    example_dir.mkdir(parents=True, exist_ok=True)

    concept_results = intervention_explainer.evaluate(
        image=image,
        activation_maps=activation_maps,
        meta=meta,
        detection_a=detection_a,
        detection_b=detection_b,
        pair_union=pair_union,
        counterfactual_dir=example_dir / "counterfactuals",
    )

    dashboard_path = create_dashboard(
        image=image,
        image_id=pair.image_id,
        detection_a=detection_a,
        detection_b=detection_b,
        pair_union=pair_union,
        concept_results=concept_results,
        output_stem=example_dir / "dashboard",
    )

    rows: List[Dict[str, Any]] = []
    for result in concept_results:
        rows.append(
            {
                "image_id": pair.image_id,
                "file_name": pair.file_name,
                "object_a": pair.object_a,
                "object_b": pair.object_b,
                "concept_id": result.concept_index + 1,
                "auto_region_label": result.auto_region_label,
                "effect_score_CE_k": result.effect_score,
                "original_score_a": result.original_score_a,
                "original_score_b": result.original_score_b,
                "original_joint_score": (
                    result.original_score_a * result.original_score_b
                ),
                "post_score_a": result.post_score_a,
                "post_score_b": result.post_score_b,
                "post_joint_score": (
                    result.post_score_a * result.post_score_b
                ),
                "mask_fraction_of_union": result.mask_fraction,
            }
        )
    pd.DataFrame(rows).to_csv(
        example_dir / "concept_scores.csv", index=False
    )

    summary = {
        "image_id": pair.image_id,
        "file_name": pair.file_name,
        "object_a": pair.object_a,
        "object_b": pair.object_b,
        "detector_score_a": detection_a.score,
        "detector_score_b": detection_b.score,
        "original_joint_score": detection_a.score * detection_b.score,
        "top_effect_score": max(
            result.effect_score for result in concept_results
        ),
        "dashboard_path": str(dashboard_path),
    }
    with open(example_dir / "summary.json", "w", encoding="utf-8") as file:
        json.dump(summary, file, indent=2)
    return summary


def run_coco_generation() -> pd.DataFrame:
    ensure_coco_files()
    selector = COCOPairSelector(
        COCO_ANNOTATION_FILE, COCO_IMAGE_DIR
    )
    processor = YOLOv5Processor()

    summaries: List[Dict[str, Any]] = []
    dashboard_paths: List[Path] = []
    used_image_ids: set[int] = set()

    for spec in PAIR_SPECS:
        if len(summaries) >= TARGET_RESULTS:
            break

        print(f"\nSearching COCO pair: {spec.object_a} + {spec.object_b}")
        candidates = selector.candidate_pairs(spec)
        successes_for_pair = 0

        for candidate in tqdm(candidates, desc=f"{spec.object_a}+{spec.object_b}"):
            if candidate.image_id in used_image_ids:
                continue
            try:
                summary = analyze_ground_truth_pair(
                    processor, candidate, selector
                )
            except Exception as error:
                print(
                    f"Skipped COCO image {candidate.image_id}: "
                    f"{type(error).__name__}: {error}"
                )
                continue

            if summary is None:
                continue

            summaries.append(summary)
            dashboard_paths.append(Path(summary["dashboard_path"]))
            used_image_ids.add(candidate.image_id)
            successes_for_pair += 1
            print(
                f"Saved result {len(summaries)}/{TARGET_RESULTS}: "
                f"COCO {candidate.image_id}, "
                f"{spec.object_a} + {spec.object_b}"
            )

            if successes_for_pair >= spec.max_examples:
                break
            if len(summaries) >= TARGET_RESULTS:
                break

    if len(summaries) < TARGET_RESULTS:
        print(
            f"\nWarning: only {len(summaries)} valid results were generated. "
            "Increase MAX_CANDIDATES_PER_PAIR, lower the initial confidence "
            "slightly, or add more PairSpec entries."
        )

    summary_frame = pd.DataFrame(summaries)
    summary_frame.to_csv(OUTPUT_DIR / "all_results_summary.csv", index=False)

    manifest = {
        "configuration": {
            "model": MODEL_NAME,
            "input_size": MODEL_INPUT_SIZE,
            "target_results": TARGET_RESULTS,
            "K": K_CONCEPTS,
            "temperature": SOFTMAX_TEMPERATURE,
            "activation_percentile": ACTIVATION_PERCENTILE,
            "blur_radius": BLUR_RADIUS,
            "initial_detection_conf": INITIAL_DETECTION_CONF,
            "intervention_detection_conf": INTERVENTION_DETECTION_CONF,
            "matching_iou_threshold": MATCH_IOU_THRESHOLD,
            "seed": SEED,
        },
        "results": summaries,
    }
    with open(OUTPUT_DIR / "run_manifest.json", "w", encoding="utf-8") as file:
        json.dump(manifest, file, indent=2)

    if dashboard_paths:
        create_contact_sheet(
            dashboard_paths,
            OUTPUT_DIR / f"composite_{len(dashboard_paths)}_examples.png",
            columns=2,
        )

    print(f"\nFinished. Outputs are in: {OUTPUT_DIR}")
    return summary_frame
