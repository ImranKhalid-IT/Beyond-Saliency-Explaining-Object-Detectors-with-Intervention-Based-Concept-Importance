from __future__ import annotations

import json
import random
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional
import time
import numpy as np
import pandas as pd
import torch
from PIL import Image
from tqdm.auto import tqdm
from ..config import *
from ..baselines.source_registry import clone_public_sources
from ..baselines.unified import compute_unified_baselines, create_unified_comparison_figure, save_map_arrays
from ..concepts.kmeans import KMeansConceptExplainer
from ..data.coco import COCOPairSelector, ensure_coco_files
from ..interventions.relational import RelationalInterventionExplainer
from ..models.yolov5 import YOLOv5Processor, match_detection_to_ground_truth
from ..schemas import GroundTruthPair
from ..utils.geometry import box_area, union_box
from ..visualization.relational import combined_top_concept_heatmap, create_contact_sheet

def analyze_pair_with_all_baselines(
    processor: YOLOv5Processor,
    pair: GroundTruthPair,
    selector: COCOPairSelector,
) -> Optional[Dict[str, Any]]:
    image_path = selector.image_path(pair)
    if not image_path.exists():
        return None
    image = Image.open(image_path).convert("RGB")
    image_area = float(image.width * image.height)
    detections = processor.detect(image, conf_threshold=INITIAL_DETECTION_CONF)
    detection_a = match_detection_to_ground_truth(
        detections, pair.object_a, pair.box_a, minimum_iou=BASELINE_MATCH_IOU
    )
    detection_b = match_detection_to_ground_truth(
        detections, pair.object_b, pair.box_b, minimum_iou=BASELINE_MATCH_IOU
    )
    if detection_a is None or detection_b is None:
        return None
    if box_area(detection_a.box_xyxy) < image_area * 0.04:
        return None
    if box_area(detection_b.box_xyxy) < image_area * 0.03:
        return None

    pair_union = union_box(detection_a.box_xyxy, detection_b.box_xyxy)
    feature_tensor, feature_meta = processor.extract_features(image)

    rce_start = time.perf_counter()
    activation_maps = KMeansConceptExplainer().discover(
        feature_tensor, pair_union, feature_meta
    )
    rce_results = RelationalInterventionExplainer(
        processor, matching_iou=BASELINE_MATCH_IOU
    ).evaluate(
        image=image,
        activation_maps=activation_maps,
        meta=feature_meta,
        detection_a=detection_a,
        detection_b=detection_b,
        pair_union=pair_union,
    )
    rce_runtime = time.perf_counter() - rce_start

    baseline_result = compute_unified_baselines(
        processor,
        image,
        detection_a,
        detection_b,
        feature_tensor,
        feature_meta,
    )
    baseline_result.runtimes["RCE (ours)"] = rce_runtime

    stem = (
        f"coco_{pair.image_id}_{pair.object_a.replace(' ', '_')}_"
        f"{pair.object_b.replace(' ', '_')}"
    )
    example_dir = BASELINE_ROOT / stem
    example_dir.mkdir(parents=True, exist_ok=True)
    save_map_arrays(baseline_result.maps, example_dir / "maps")
    rce_map = combined_top_concept_heatmap(rce_results, pair_union, image.size, top_n=3)
    np.save(example_dir / "maps" / "rce_relational.npy", rce_map.astype(np.float32))

    figure_path = create_unified_comparison_figure(
        image=image,
        image_id=pair.image_id,
        detection_a=detection_a,
        detection_b=detection_b,
        pair_union=pair_union,
        baseline_result=baseline_result,
        rce_concepts=rce_results,
        output_stem=example_dir / "unified_comparison",
    )

    rce_rows = [
        {
            "concept": item.concept_index + 1,
            "region_label": item.auto_region_label,
            "CE_k": item.effect_score,
            "score_drop_a": item.original_score_a - item.post_score_a,
            "score_drop_b": item.original_score_b - item.post_score_b,
            "mask_fraction": item.mask_fraction,
        }
        for item in sorted(rce_results, key=lambda value: value.effect_score, reverse=True)
    ]
    pd.DataFrame(rce_rows).to_csv(example_dir / "rce_concept_scores.csv", index=False)
    pd.DataFrame(
        [{"method": method, "seconds": seconds} for method, seconds in baseline_result.runtimes.items()]
    ).to_csv(example_dir / "runtime.csv", index=False)

    metadata = {
        "image_id": pair.image_id,
        "file_name": pair.file_name,
        "object_a": asdict(detection_a),
        "object_b": asdict(detection_b),
        "pair_union": pair_union.tolist(),
        "baseline_metadata": baseline_result.metadata,
        "runtimes": baseline_result.runtimes,
        "figure_path": str(figure_path),
    }
    # Convert NumPy arrays in dataclass dictionaries to JSON-safe lists.
    metadata["object_a"]["box_xyxy"] = detection_a.box_xyxy.tolist()
    metadata["object_b"]["box_xyxy"] = detection_b.box_xyxy.tolist()
    with open(example_dir / "metadata.json", "w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=2)

    return {
        "image_id": pair.image_id,
        "object_a": pair.object_a,
        "object_b": pair.object_b,
        "score_a": detection_a.score,
        "score_b": detection_b.score,
        "top_RCE_CE_k": max(item.effect_score for item in rce_results),
        "comparison_figure": str(figure_path),
        **{f"runtime_{key}": value for key, value in baseline_result.runtimes.items()},
    }


def run_full_baseline_comparison() -> pd.DataFrame:
    print(METHOD_SCOPE.to_string(index=False))
    clone_public_sources()
    ensure_coco_files()
    selector = COCOPairSelector(COCO_ANNOTATION_FILE, COCO_IMAGE_DIR)
    processor = YOLOv5Processor(
        model_name=MODEL_NAME,
        device=DEVICE,
        input_size=MODEL_INPUT_SIZE,
    )

    summaries: List[Dict[str, Any]] = []
    figures: List[Path] = []
    used_ids: set[int] = set()
    for spec in PAIR_SPECS:
        if len(summaries) >= TARGET_RESULTS:
            break
        print(f"\nSearching: {spec.object_a} + {spec.object_b}")
        successful_for_pair = 0
        for candidate in selector.candidate_pairs(spec):
            if candidate.image_id in used_ids:
                continue
            try:
                summary = analyze_pair_with_all_baselines(processor, candidate, selector)
            except torch.cuda.OutOfMemoryError:
                print(f"Skipped {candidate.image_id}: CUDA out of memory.")
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                continue
            except Exception as error:
                print(f"Skipped {candidate.image_id}: {type(error).__name__}: {error}")
                continue
            if summary is None:
                continue
            summaries.append(summary)
            figures.append(Path(summary["comparison_figure"]))
            used_ids.add(candidate.image_id)
            successful_for_pair += 1
            print(
                f"Saved {len(summaries)}/{TARGET_RESULTS}: COCO {candidate.image_id} "
                f"({spec.object_a}+{spec.object_b})"
            )
            if successful_for_pair >= spec.max_examples or len(summaries) >= TARGET_RESULTS:
                break

    result_frame = pd.DataFrame(summaries)
    result_frame.to_csv(BASELINE_ROOT / "all_comparison_results.csv", index=False)
    if figures:
        create_contact_sheet(
            figures,
            BASELINE_ROOT / f"all_{len(figures)}_comparison_examples.png",
            columns=1,
            panel_width=2400,
        )
    manifest = {
        "detector": MODEL_NAME,
        "input_size": MODEL_INPUT_SIZE,
        "paper_mode": PAPER_MODE,
        "D_RISE_masks": DRISE_MASK_COUNT,
        "target_results": TARGET_RESULTS,
        "method_scope": METHOD_SCOPE.to_dict(orient="records"),
        "results": summaries,
    }
    with open(BASELINE_ROOT / "comparison_manifest.json", "w", encoding="utf-8") as file:
        json.dump(manifest, file, indent=2)
    print(f"\nFinished. Results: {BASELINE_ROOT}")
    return result_frame
