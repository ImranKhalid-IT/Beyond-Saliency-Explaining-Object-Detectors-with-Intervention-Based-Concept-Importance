from __future__ import annotations

from typing import Dict, List, Tuple
import cv2
import numpy as np
import torch
from PIL import Image
from ..config import DEVICE

class YOLOv5_Processor:
    """Handles YOLOv5 model loading, prediction, and feature extraction."""
    def __init__(self, model_name='yolov5l', device='cpu'):
        self.device = device
        self.captured_features = None
        # Load model
        self.model = torch.hub.load(
            'ultralytics/yolov5',
            model_name,
            pretrained=True,
            trust_repo=True
        ).to(self.device).eval()
        # The layer from which to extract features (layer 8 in YOLOv5l's backbone)
        self.hook_layer = self.model.model.model.model[8]

    def _feature_hook(self, module, input, output):
        """A hook to capture the output of a specific layer."""
        self.captured_features = output

    def get_detections_and_features(self, pil_image: Image.Image, conf_thresh=0.5, iou_thresh=0.45):
        """Runs detection and captures intermediate feature maps."""
        hook = self.hook_layer.register_forward_hook(self._feature_hook)
        self.model.conf = conf_thresh
        self.model.iou = iou_thresh

        results = self.model(pil_image)
        hook.remove()

        if self.captured_features is None:
            raise RuntimeError("Feature extraction failed.")

        dets = []
        df = results.pandas().xyxy[0]
        class_names = self.model.names
        for _, r in df.iterrows():
            class_idx = int(r['class'])
            dets.append({
                'box_xyxy': np.array([int(r.xmin), int(r.ymin), int(r.xmax), int(r.ymax)]),
                'score': float(r.confidence),
                'label_idx': class_idx,
                'class_name': class_names[class_idx]
            })

        features = self.captured_features.clone().detach()
        return dets, features

    def generate_finer_cam_heatmap(self, box_xyxy: np.ndarray, pil_size: Tuple[int, int]):
        """Generates a Finer-CAM heatmap to show where the model focuses."""
        features = self.captured_features
        if features is None:
            raise RuntimeError("Features not captured. Run get_detections_and_features first.")

        _, C, Hf, Wf = features.shape
        W_img, H_img = pil_size

        # Map image coordinates to feature map coordinates
        fx1, fy1 = int(box_xyxy[0] / W_img * Wf), int(box_xyxy[1] / H_img * Hf)
        fx2, fy2 = int(box_xyxy[2] / W_img * Wf), int(box_xyxy[3] / H_img * Hf)

        # Create foreground and background masks
        fg_mask = torch.zeros(Hf, Wf, device=features.device)
        if fy1 < fy2 and fx1 < fx2:
            fg_mask[fy1:fy2, fx1:fx2] = 1
        bg_mask = 1 - fg_mask

        # Calculate weights by contrasting foreground and background features
        fg_feats = (features * fg_mask).sum(dim=[2, 3]) / (fg_mask.sum() + 1e-8)
        bg_feats = (features * bg_mask).sum(dim=[2, 3]) / (bg_mask.sum() + 1e-8)
        weights = (fg_feats - bg_feats).view(1, C, 1, 1)

        # Generate CAM
        finer_cam = torch.sum(features * weights, dim=1).squeeze()
        finer_cam = torch.relu(finer_cam)

        # Normalize and resize
        if finer_cam.max() > 0:
            finer_cam = (finer_cam - finer_cam.min()) / finer_cam.max()

        return cv2.resize(finer_cam.cpu().numpy(), pil_size)
