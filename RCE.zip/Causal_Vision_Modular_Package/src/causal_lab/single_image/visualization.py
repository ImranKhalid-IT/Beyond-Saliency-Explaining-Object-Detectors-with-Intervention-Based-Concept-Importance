from __future__ import annotations

from typing import Dict, List
import cv2
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
import torch

def visualize_full_explanation(
    pil_img: Image.Image,
    primary_det: Dict,
    finer_cam_map: np.ndarray,
    spatial_activations: torch.Tensor,
    causal_effects: Dict
):
    """Generates a step-by-step visualization of the entire explanation process."""
    img_np = np.array(pil_img)
    box = primary_det['box_xyxy']
    W_img, H_img = pil_img.size

    # --- Panel 1: Original Detection ---
    img_with_box = img_np.copy()
    x1, y1, x2, y2 = map(int, box)
    cv2.rectangle(img_with_box, (x1, y1), (x2, y2), (255, 255, 0), 3)
    cv2.putText(img_with_box, f"{primary_det['class_name']}: {primary_det['score']:.2f}",
                (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 0), 2)

    # --- Panel 2: Finer-CAM Heatmap (Where?) ---
    heatmap_jet = cv2.applyColorMap((finer_cam_map * 255).astype(np.uint8), cv2.COLORMAP_JET)
    blended_finer_cam = cv2.addWeighted(img_np, 0.6, cv2.cvtColor(heatmap_jet, cv2.COLOR_BGR2RGB), 0.4, 0)

    # --- Panel 3: Top Causal Concepts Overlay (What?) ---
    sorted_effects = sorted(causal_effects.items(), key=lambda item: item[1], reverse=True)
    top_k = 3 # Display the top 3 concepts for clarity
    colors = plt.get_cmap('viridis', top_k)

    concept_overlay = np.zeros_like(img_np, dtype=np.float32)
    for i in range(top_k):
        if i >= len(sorted_effects): break
        concept_idx = sorted_effects[i][0]
        concept_map = spatial_activations[0, concept_idx].cpu().numpy()
        map_resized = cv2.resize(concept_map, (W_img, H_img))
        if map_resized.max() > 0:
            map_norm = (map_resized - map_resized.min()) / (map_resized.max() - map_resized.min())
        else:
            continue
        mask = (map_norm > 0.7).astype(np.uint8)
        color = np.array(colors(i)[:3])
        concept_overlay[mask == 1] = color
    blended_concepts = (img_np / 255.0 * 0.5) + (concept_overlay * 0.5)
    blended_concepts = (blended_concepts * 255).astype(np.uint8)

    # --- Panel 4: Causal Importance Bar Chart (Why?) ---
    fig_bar, ax_bar = plt.subplots(figsize=(6, 4), dpi=100)
    labels = [f"Concept {item[0] + 1}" for item in sorted_effects]
    scores = [item[1] for item in sorted_effects]
    ax_bar.barh(labels[::-1], scores[::-1], color='skyblue', edgecolor='black')
    ax_bar.set_title("Causal Importance of Concepts")
    ax_bar.set_xlabel("Prediction Score Drop (Higher is More Important)")
    plt.tight_layout()
    fig_bar.canvas.draw()
    buf = fig_bar.canvas.buffer_rgba()
    bar_chart_img = np.array(buf)
    bar_chart_img = cv2.cvtColor(bar_chart_img, cv2.COLOR_RGBA2BGR)
    plt.close(fig_bar)

    # --- Display Step-by-Step and Final Dashboard ---
    print("\n--- Step-by-Step Explanation ---")
    plt.figure(figsize=(6, 6)); plt.imshow(img_with_box); plt.title("Step 1: Object Detection"); plt.axis('off'); plt.show()
    plt.figure(figsize=(6, 6)); plt.imshow(blended_finer_cam); plt.title("Step 2: Finer-CAM Heatmap (Where?)"); plt.axis('off'); plt.show()
    plt.figure(figsize=(6, 6)); plt.imshow(blended_concepts); plt.title(f"Step 3: Top {top_k} Causal Concepts (What?)"); plt.axis('off'); plt.show()
    plt.figure(figsize=(7, 5)); plt.imshow(bar_chart_img); plt.title("Step 4: Causal Importance Ranking (Why?)"); plt.axis('off'); plt.show()

    # --- Final Combined Dashboard ---
    print("\n--- Combined Explanation Dashboard ---")
    fig_dash, axes = plt.subplots(2, 2, figsize=(12, 12))
    fig_dash.suptitle("YOLOv5 Causal Explanation Dashboard", fontsize=16)
    axes[0, 0].imshow(img_with_box); axes[0, 0].set_title("1. Object Detection"); axes[0, 0].axis('off')
    axes[0, 1].imshow(blended_finer_cam); axes[0, 1].set_title("2. Finer-CAM (Where?)"); axes[0, 1].axis('off')
    axes[1, 0].imshow(blended_concepts); axes[1, 0].set_title(f"3. Top {top_k} Concepts (What?)"); axes[1, 0].axis('off')
    axes[1, 1].imshow(bar_chart_img); axes[1, 1].set_title("4. Causal Ranking (Why?)"); axes[1, 1].axis('off')
    plt.tight_layout(rect=[0, 0.03, 1, 0.95]); plt.show()

    # --- Final, Focused Result Visualization ---
    print("\n--- Primary Causal Finding ---")
    most_causal_idx, most_causal_effect = sorted_effects[0]
    original_score = primary_det['score']
    percentage_drop = (most_causal_effect / original_score) * 100 if original_score > 0 else 0
    concept_map = spatial_activations[0, most_causal_idx].cpu().numpy()
    map_resized = cv2.resize(concept_map, pil_img.size)
    if map_resized.max() > 0: map_norm = (map_resized - map_resized.min()) / (map_resized.max() - map_resized.min())
    else: map_norm = map_resized
    heatmap_jet = cv2.applyColorMap((map_norm * 255).astype(np.uint8), cv2.COLORMAP_JET)
    blended_final = cv2.addWeighted(np.array(pil_img), 0.6, cv2.cvtColor(heatmap_jet, cv2.COLOR_BGR2RGB), 0.4, 0)
    plt.figure(figsize=(8, 8))
    plt.imshow(blended_final)
    title_text = f"Main Finding: Removing Concept {most_causal_idx + 1}\ncaused a {percentage_drop:.1f}% drop in confidence!"
    plt.title(title_text, fontsize=14, weight='bold')
    plt.axis('off')
    plt.show()


def visualize_clever_hans_comparison(
    pil_img: Image.Image,
    finer_cam_map: np.ndarray,
    activation_ranked_concepts: list,
    causal_ranked_concepts: list,
    spatial_activations: torch.Tensor,
    primary_det: dict
):
    """Generates a 1x3 comparison figure to diagnose spurious correlations."""
    img_np = np.array(pil_img)
    W_img, H_img = pil_img.size

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    fig.suptitle(f"Diagnosing Spurious Correlation for '{primary_det['class_name']}' Detection", fontsize=16, weight='bold')

    # Panel (a): Finer-CAM
    heatmap_jet = cv2.applyColorMap((finer_cam_map * 255).astype(np.uint8), cv2.COLORMAP_JET)
    blended_finer_cam = cv2.addWeighted(img_np, 0.6, cv2.cvtColor(heatmap_jet, cv2.COLOR_BGR2RGB), 0.4, 0)
    axes[0].imshow(blended_finer_cam); axes[0].set_title("(a) Finer-CAM Heatmap\n(Correlation-based Saliency)", fontsize=12); axes[0].axis('off')

    def create_concept_overlay(img_np, concept_idx, spatial_activations, color):
        concept_map = spatial_activations[0, concept_idx].cpu().numpy()
        map_resized = cv2.resize(concept_map, (W_img, H_img))
        if map_resized.max() > 0: map_norm = (map_resized - map_resized.min()) / (map_resized.max() - map_resized.min())
        else: map_norm = map_resized
        mask = (map_norm > 0.7).astype(np.uint8)
        overlay = np.zeros_like(img_np, dtype=np.float32); overlay[mask == 1] = color
        blended = (img_np / 255.0 * 0.4) + (overlay * 0.6)
        return (blended * 255).astype(np.uint8)

    # Panel (b): Top Concept by Activation
    top_activation_idx = activation_ranked_concepts[0][0]
    activation_overlay = create_concept_overlay(img_np, top_activation_idx, spatial_activations, color=[1.0, 0.5, 0.0])
    axes[1].imshow(activation_overlay); axes[1].set_title(f"(b) Top Activation-Ranked Concept\n(Concept {top_activation_idx+1}: Possibly Spurious)", fontsize=12); axes[1].axis('off')

    # Panel (c): Top Concept by Causal Score
    top_causal_idx = causal_ranked_concepts[0][0]
    causal_overlay = create_concept_overlay(img_np, top_causal_idx, spatial_activations, color=[0.0, 0.7, 1.0])
    axes[2].imshow(causal_overlay); axes[2].set_title(f"(c) Top Causal-Ranked Concept\n(Concept {top_causal_idx+1}: Causally Important)", fontsize=12); axes[2].axis('off')

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()
