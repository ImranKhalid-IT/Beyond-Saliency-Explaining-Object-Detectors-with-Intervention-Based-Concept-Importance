from __future__ import annotations
import argparse
import urllib.request
from pathlib import Path
import torch
from PIL import Image
from ..access import verify_access
from ..config import DEVICE
from .model import YOLOv5_Processor
from .concepts import CRAFT_Concept_Explainer
from .intervention import YoloCausalExplainer
from .visualization import visualize_full_explanation, visualize_clever_hans_comparison

DEFAULT_IMAGE_URL = "https://images.pexels.com/photos/104827/cat-pet-animal-domestic-104827.jpeg"

def run(image_path: Path, concepts: int = 8) -> None:
    verify_access()
    if not image_path.exists():
        image_path.parent.mkdir(parents=True, exist_ok=True)
        urllib.request.urlretrieve(DEFAULT_IMAGE_URL, image_path)
    pil_img = Image.open(image_path).convert("RGB")
    processor = YOLOv5_Processor(device=DEVICE)
    craft = CRAFT_Concept_Explainer(K=concepts, device=DEVICE)
    detections, features = processor.get_detections_and_features(pil_img, conf_thresh=0.5)
    if not detections:
        print("No high-confidence detections found.")
        return
    primary = max(detections, key=lambda d: d["score"])
    box = primary["box_xyxy"]
    finer = processor.generate_finer_cam_heatmap(box, pil_img.size)
    if not craft.fit_nmf(features, box, pil_img.size):
        return
    activations = craft.get_spatial_activations(features)
    effects = YoloCausalExplainer(processor).run_intervention(pil_img, detections, activations, primary)
    causal_ranked = sorted(effects.items(), key=lambda item: item[1], reverse=True)
    _, K, Hf, Wf = activations.shape
    W_img, H_img = pil_img.size
    fx1, fy1 = int(box[0] / W_img * Wf), int(box[1] / H_img * Hf)
    fx2, fy2 = int(box[2] / W_img * Wf), int(box[3] / H_img * Hf)
    activation_effects = {}
    for k in range(K):
        mask = torch.zeros(Hf, Wf, device=DEVICE)
        if fy1 < fy2 and fx1 < fx2:
            mask[fy1:fy2, fx1:fx2] = 1
        activation_effects[k] = ((activations[0, k] * mask).sum() / (mask.sum() + 1e-8)).item()
    activation_ranked = sorted(activation_effects.items(), key=lambda item: item[1], reverse=True)
    visualize_full_explanation(pil_img, primary, finer, activations, effects)
    visualize_clever_hans_comparison(pil_img, finer, activation_ranked, causal_ranked, activations, primary)

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", default="data/example.jpg")
    parser.add_argument("--concepts", type=int, default=8)
    args = parser.parse_args()
    run(Path(args.image), args.concepts)

if __name__ == "__main__":
    main()
