from __future__ import annotations

from typing import Tuple
import numpy as np
import torch
from sklearn.decomposition import NMF

class CRAFT_Concept_Explainer:
    """Handles NMF-based concept extraction from feature maps."""
    def __init__(self, K, nmf_iter=200, device='cpu'):
        self.K = K
        self.device = device
        self.nmf_iter = nmf_iter
        self.W = None # Concept basis vectors (D x K)

    def fit_nmf(self, feats: torch.Tensor, box: np.ndarray, orig_size: Tuple[int, int]):
        """Fits NMF on features within a bounding box to find concepts."""
        B, C, Hf, Wf = feats.shape
        W_img, H_img = orig_size
        fx1, fy1 = int(box[0] / W_img * Wf), int(box[1] / H_img * Hf)
        fx2, fy2 = int(box[2] / W_img * Wf), int(box[3] / H_img * Hf)

        mask = torch.zeros(Hf, Wf, device=feats.device)
        if fy1 < fy2 and fx1 < fx2:
            mask[fy1:fy2, fx1:fx2] = 1

        A = feats.permute(0, 2, 3, 1).reshape(-1, C)
        A_masked = A[mask.flatten() > 0]
        A_masked_non_negative = torch.relu(A_masked).cpu().numpy()

        if A_masked_non_negative.shape[0] < self.K:
              print("Warning: Not enough feature vectors in the box to extract concepts. Skipping NMF.")
              return False

        nmf = NMF(n_components=self.K, max_iter=self.nmf_iter, init='nndsvda', random_state=42)
        nmf.fit(A_masked_non_negative)
        self.W = torch.from_numpy(nmf.components_).to(self.device).float()
        return True

    def get_spatial_activations(self, feats: torch.Tensor):
        """Calculates the spatial activation map for each concept."""
        if self.W is None:
            raise RuntimeError("NMF model has not been fit. Call fit_nmf() first.")
        B, C, Hf, Wf = feats.shape
        A = feats.permute(0, 2, 3, 1).reshape(B * Hf * Wf, C)
        A_non_negative = torch.relu(A)
        # Project features onto concept basis to get activations
        U = A_non_negative @ torch.linalg.pinv(self.W)
        return U.reshape(B, Hf, Wf, self.K).permute(0, 3, 1, 2)
