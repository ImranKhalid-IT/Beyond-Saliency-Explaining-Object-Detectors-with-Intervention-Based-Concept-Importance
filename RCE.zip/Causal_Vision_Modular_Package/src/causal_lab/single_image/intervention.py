from __future__ import annotations

from typing import Dict, List
import cv2
import numpy as np
from PIL import Image, ImageFilter
import torch
from .model import YOLOv5_Processor

class YoloCausalExplainer:
    """
    Implements a robust causal intervention mechanism by ablating concepts
    from the input image and re-running the full model.
    """
    def __init__(self, processor: YOLOv5_Processor):
        self.processor = processor

    def run_intervention(self, pil_image: Image.Image, original_detections: List[Dict], spatial_activations: torch.Tensor, target_det: Dict):
        """
        Runs intervention by ablating each concept from the input image and
        measuring the drop in the target object's detection score.
        """
        causal_effects = {}
        original_score = target_det['score']
        target_label_idx = target_det['label_idx']

        B, K, Hf, Wf = spatial_activations.shape
        W_img, H_img = pil_image.size

        for k_concept in range(K):
            # Step 1: Get the concept activation map and create a mask
            concept_map = spatial_activations[0, k_concept].cpu().numpy()
            map_resized = cv2.resize(concept_map, (W_img, H_img))

            if map_resized.max() > 0:
                map_norm = (map_resized - map_resized.min()) / (map_resized.max() - map_resized.min())
            else:
                map_norm = map_resized

            # Create a binary mask for pixels where concept activation is high
            ablation_mask_np = (map_norm > np.percentile(map_norm, 85)).astype(np.uint8)
            ablation_mask_pil = Image.fromarray(ablation_mask_np * 255, 'L')

            # Step 2: Create the ablated image by blurring the concept area
            img_blurred = pil_image.filter(ImageFilter.GaussianBlur(radius=15))
            img_ablated = Image.composite(img_blurred, pil_image, ablation_mask_pil)

            # Step 3: Re-run detection on the ablated image
            new_detections, _ = self.processor.get_detections_and_features(img_ablated)

            # Step 4: Find the new score for the target object
            new_score = 0.0
            # Find all newly detected objects with the same class label
            new_target_dets = [d for d in new_detections if d['label_idx'] == target_label_idx]
            if new_target_dets:
                # Assume the highest-scoring one is our target
                best_new_det = max(new_target_dets, key=lambda d: d['score'])
                new_score = best_new_det['score']

            score_drop = original_score - new_score
            causal_effects[k_concept] = score_drop

        return causal_effects
