from __future__ import annotations
import os
from pathlib import Path
from typing import List
import pandas as pd
import torch
from .schemas import PairSpec

PROJECT_ROOT = Path(os.getenv("CAUSAL_LAB_ROOT", Path(__file__).resolve().parents[2]))
SEED = int(os.getenv("CAUSAL_LAB_SEED", "42"))
DEVICE = os.getenv("CAUSAL_LAB_DEVICE", "cuda" if torch.cuda.is_available() else "cpu")
COCO_ROOT = Path(os.getenv("COCO_ROOT", PROJECT_ROOT / "data" / "coco"))
COCO_IMAGE_DIR = COCO_ROOT / "val2017"
COCO_ANNOTATION_FILE = COCO_ROOT / "annotations" / "instances_val2017.json"
OUTPUT_DIR = Path(os.getenv("CAUSAL_LAB_OUTPUT", PROJECT_ROOT / "outputs" / "rce"))
BASELINE_ROOT = Path(os.getenv("CAUSAL_LAB_BASELINE_OUTPUT", PROJECT_ROOT / "outputs" / "baseline_comparison"))
AUTO_DOWNLOAD_COCO = os.getenv("AUTO_DOWNLOAD_COCO", "0") == "1"
MODEL_NAME = os.getenv("MODEL_NAME", "yolov5x6")
MODEL_INPUT_SIZE = int(os.getenv("MODEL_INPUT_SIZE", "640"))
TARGET_RESULTS = int(os.getenv("TARGET_RESULTS", "2"))
MAX_CANDIDATES_PER_PAIR = int(os.getenv("MAX_CANDIDATES_PER_PAIR", "50"))
K_CONCEPTS = int(os.getenv("K_CONCEPTS", "6"))
SOFTMAX_TEMPERATURE = float(os.getenv("SOFTMAX_TEMPERATURE", "0.05"))
ACTIVATION_PERCENTILE = float(os.getenv("ACTIVATION_PERCENTILE", "85"))
BLUR_RADIUS = int(os.getenv("BLUR_RADIUS", "15"))
INITIAL_DETECTION_CONF = float(os.getenv("INITIAL_DETECTION_CONF", "0.01"))
INTERVENTION_DETECTION_CONF = float(os.getenv("INTERVENTION_DETECTION_CONF", "0.01"))
MATCH_IOU_THRESHOLD = float(os.getenv("MATCH_IOU_THRESHOLD", "0.1"))
SHOW_TOP_CONCEPTS = int(os.getenv("SHOW_TOP_CONCEPTS", "6"))
SAVE_PDF = os.getenv("SAVE_PDF", "1") == "1"
SAVE_COUNTERFACTUALS = os.getenv("SAVE_COUNTERFACTUALS", "0") == "1"
PAPER_MODE = os.getenv("PAPER_MODE", "0") == "1"
DRISE_MASK_COUNT = 1000 if PAPER_MODE else 64
DRISE_BATCH_SIZE = 8 if PAPER_MODE else 4
DRISE_GRID_SIZE = 16
DRISE_KEEP_PROBABILITY = 0.5
CRAFT_CONCEPTS = 8 if PAPER_MODE else 6
CRAFT_EVALUATED_CONCEPTS = 6 if PAPER_MODE else 3
FINER_ALPHA = 1.0
FINER_REFERENCE_COUNT = 3
BASELINE_MATCH_IOU = 0.1

PAIR_SPECS: List[PairSpec] = [
    PairSpec("person", "laptop", max_gap_fraction=1.0, max_union_fraction=1.0, max_examples=3),
    PairSpec("dog", "frisbee", max_gap_fraction=1.0, max_union_fraction=1.0, max_examples=3),
    PairSpec("person", "horse", max_gap_fraction=1.0, max_union_fraction=1.0, max_examples=3),
    PairSpec("person", "motorcycle", max_gap_fraction=1.0, max_union_fraction=1.0, max_examples=3),
]

SOURCE_REPOSITORIES = {
    "ODAM": "https://github.com/Cyang-Zhao/ODAM.git",
    "CRAFT": "https://github.com/deel-ai/Craft.git",
    "D-RISE": "https://github.com/hysts/pytorch_D-RISE.git",
    "Finer-CAM": "https://github.com/Imageomics/Finer-CAM.git",
}

METHOD_SCOPE = pd.DataFrame([
    {"method":"D-RISE","native_scope":"instance-specific black-box saliency","comparison_output":"one saliency map per detected object","concept_discovery":False,"explicit_pair_relation":False,"adapter_status":"public PyTorch D-RISE algorithm adapted to YOLOv5x6"},
    {"method":"ODAM","native_scope":"instance-specific gradient attribution","comparison_output":"one gradient activation map per detected object","concept_discovery":False,"explicit_pair_relation":False,"adapter_status":"official ODAM objective adapted to YOLOv5x6 raw predictions"},
    {"method":"Finer-CAM","native_scope":"class-discriminative CAM","comparison_output":"one class-relative map per detected object","concept_discovery":False,"explicit_pair_relation":False,"adapter_status":"official weighted relative target adapted to YOLOv5x6"},
    {"method":"CRAFT","native_scope":"concept discovery and concept importance","comparison_output":"object-conditioned concept maps","concept_discovery":True,"explicit_pair_relation":False,"adapter_status":"CRAFT NMF concept core adapted to detector feature maps"},
    {"method":"RCE (ours)","native_scope":"relational concept explanation","comparison_output":"pair-conditioned concepts and joint intervention scores","concept_discovery":True,"explicit_pair_relation":True,"adapter_status":"user-provided New_COCO_Experi model"},
])
