"""Modular causal vision research package."""
__version__ = "1.0.0"
