from __future__ import annotations
import hashlib
import os

_EXPECTED_SHA256 = "ef8a0b2b0f8a8552a0c64c6ad37410aa99e792ed03890cac3297ecb5da5e40a8"

class AccessDenied(RuntimeError):
    pass

def verify_access() -> None:
    token = os.getenv("CAUSAL_LAB_ACCESS_TOKEN", "").strip()
    supplied = hashlib.sha256(token.encode("utf-8")).hexdigest()
    if not token or supplied != _EXPECTED_SHA256:
        raise AccessDenied(
            "Owner access token is missing or invalid. "
            "Set CAUSAL_LAB_ACCESS_TOKEN in a private .env or shell session."
        )
