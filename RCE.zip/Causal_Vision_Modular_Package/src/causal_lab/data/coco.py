from __future__ import annotations

import json
import random
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple
from pycocotools.coco import COCO
from tqdm.auto import tqdm
from ..config import AUTO_DOWNLOAD_COCO, COCO_ANNOTATION_FILE, COCO_IMAGE_DIR, COCO_ROOT, MAX_CANDIDATES_PER_PAIR
from ..schemas import GroundTruthPair, PairSpec
from ..utils.geometry import box_area, normalized_box_gap, normalized_center_distance, union_box, xywh_to_xyxy

def _download_with_progress(url: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    print(f"Downloading: {url}")
    urllib.request.urlretrieve(url, destination)


def _extract_zip(zip_path: Path, destination: Path) -> None:
    print(f"Extracting: {zip_path.name}")
    with zipfile.ZipFile(zip_path, "r") as archive:
        archive.extractall(destination)


def ensure_coco_files(auto_download: bool = AUTO_DOWNLOAD_COCO) -> None:
    if COCO_IMAGE_DIR.exists() and COCO_ANNOTATION_FILE.exists():
        print("COCO 2017 validation images and annotations are available.")
        return

    if not auto_download:
        raise FileNotFoundError(
            "COCO files were not found.\n"
            f"Expected images: {COCO_IMAGE_DIR}\n"
            f"Expected annotations: {COCO_ANNOTATION_FILE}\n\n"
            "Upload/mount the dataset at these paths, or set "
            "AUTO_DOWNLOAD_COCO = True and rerun."
        )

    COCO_ROOT.mkdir(parents=True, exist_ok=True)
    image_zip = COCO_ROOT / "val2017.zip"
    annotation_zip = COCO_ROOT / "annotations_trainval2017.zip"

    if not image_zip.exists():
        _download_with_progress(
            "https://images.cocodataset.org/zips/val2017.zip", image_zip
        )
    if not annotation_zip.exists():
        _download_with_progress(
            "https://images.cocodataset.org/annotations/annotations_trainval2017.zip",
            annotation_zip,
        )

    if not COCO_IMAGE_DIR.exists():
        _extract_zip(image_zip, COCO_ROOT)
    if not COCO_ANNOTATION_FILE.exists():
        _extract_zip(annotation_zip, COCO_ROOT)

    if not (COCO_IMAGE_DIR.exists() and COCO_ANNOTATION_FILE.exists()):
        raise RuntimeError("COCO download/extraction did not create the expected files.")


class COCOPairSelector:
    def __init__(self, annotation_file: Path, image_dir: Path) -> None:
        self.coco = COCO(str(annotation_file))
        self.image_dir = Path(image_dir)
        categories = self.coco.loadCats(self.coco.getCatIds())
        self.category_id = {category["name"]: category["id"] for category in categories}

    def _annotations_for(
        self, image_id: int, category_name: str
    ) -> List[Dict[str, Any]]:
        category_id = self.category_id[category_name]
        annotation_ids = self.coco.getAnnIds(
            imgIds=[image_id], catIds=[category_id], iscrowd=False
        )
        annotations = self.coco.loadAnns(annotation_ids)
        return [
            annotation
            for annotation in annotations
            if float(annotation.get("area", 0.0)) > 1.0
        ]

    def candidate_pairs(
        self, spec: PairSpec, limit: int = MAX_CANDIDATES_PER_PAIR
    ) -> List[GroundTruthPair]:
        if spec.object_a not in self.category_id or spec.object_b not in self.category_id:
            return []

        image_ids = self.coco.getImgIds(
            catIds=[
                self.category_id[spec.object_a],
                self.category_id[spec.object_b],
            ]
        )
        scored: List[GroundTruthPair] = []

        for image_id in image_ids:
            image_info = self.coco.loadImgs([image_id])[0]
            width, height = int(image_info["width"]), int(image_info["height"])
            anns_a = self._annotations_for(image_id, spec.object_a)
            anns_b = self._annotations_for(image_id, spec.object_b)
            if not anns_a or not anns_b:
                continue

            best: Optional[GroundTruthPair] = None
            for annotation_a in anns_a:
                box_a = xywh_to_xyxy(annotation_a["bbox"])
                for annotation_b in anns_b:
                    box_b = xywh_to_xyxy(annotation_b["bbox"])
                    gap = normalized_box_gap(box_a, box_b, width, height)
                    pair_union = union_box(box_a, box_b)
                    union_fraction = box_area(pair_union) / float(width * height)
                    if gap > spec.max_gap_fraction:
                        continue
                    if union_fraction > spec.max_union_fraction:
                        continue

                    center_distance = normalized_center_distance(
                        box_a, box_b, width, height
                    )
                    # Lower is better. The score favors spatially compact,
                    # non-trivial object pairs without claiming a relation label.
                    quality = (
                        0.50 * gap
                        + 0.30 * center_distance
                        + 0.20 * union_fraction
                    )
                    candidate = GroundTruthPair(
                        image_id=int(image_id),
                        file_name=str(image_info["file_name"]),
                        width=width,
                        height=height,
                        object_a=spec.object_a,
                        object_b=spec.object_b,
                        box_a=box_a,
                        box_b=box_b,
                        quality_score=float(quality),
                    )
                    if best is None or candidate.quality_score < best.quality_score:
                        best = candidate

            if best is not None:
                scored.append(best)

        scored.sort(key=lambda item: item.quality_score)
        return scored[:limit]

    def image_path(self, pair: GroundTruthPair) -> Path:
        return self.image_dir / pair.file_name
