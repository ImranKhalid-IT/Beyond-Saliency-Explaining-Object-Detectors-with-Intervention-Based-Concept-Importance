from __future__ import annotations

from typing import List, Tuple
import numpy as np
import torch
import torch.nn.functional as F
from sklearn.cluster import KMeans
from ..config import K_CONCEPTS, SEED, SOFTMAX_TEMPERATURE
from ..schemas import ConceptResult, Detection, LetterboxMeta
from ..utils.geometry import box_mask, map_box_to_feature, normalize_map

class KMeansConceptExplainer:
    """K-Means over all feature vectors inside the selected union region."""

    def __init__(
        self,
        number_of_concepts: int = K_CONCEPTS,
        temperature: float = SOFTMAX_TEMPERATURE,
        seed: int = SEED,
    ) -> None:
        self.number_of_concepts = int(number_of_concepts)
        self.temperature = float(temperature)
        self.seed = int(seed)

    def discover(
        self,
        feature_tensor: torch.Tensor,
        relational_box: np.ndarray,
        meta: LetterboxMeta,
    ) -> torch.Tensor:
        if feature_tensor.ndim != 4 or feature_tensor.shape[0] != 1:
            raise ValueError(
                f"Expected a [1,C,H,W] feature tensor, got {feature_tensor.shape}."
            )

        _, channels, feature_h, feature_w = feature_tensor.shape
        x1, y1, x2, y2 = map_box_to_feature(
            relational_box, meta, (feature_h, feature_w)
        )
        if x2 <= x1 or y2 <= y1:
            raise RuntimeError("The relational box maps to an empty feature region.")

        feature_grid = feature_tensor[0].permute(1, 2, 0).contiguous()
        region_vectors = feature_grid[y1:y2, x1:x2].reshape(-1, channels)
        region_vectors = region_vectors[
            torch.isfinite(region_vectors).all(dim=1)
        ]
        if region_vectors.shape[0] < 2:
            raise RuntimeError("Too few valid feature vectors for concept discovery.")

        k_final = min(self.number_of_concepts, int(region_vectors.shape[0]))
        kmeans = KMeans(
            n_clusters=k_final,
            random_state=self.seed,
            n_init=10,
        )
        centers_numpy = kmeans.fit(region_vectors.cpu().numpy()).cluster_centers_
        centers = torch.as_tensor(
            centers_numpy,
            dtype=feature_tensor.dtype,
            device=feature_tensor.device,
        )

        all_vectors = feature_grid.reshape(-1, channels)
        distances = torch.cdist(all_vectors.float(), centers.float())
        similarity = F.softmax(-distances / self.temperature, dim=1)
        activation_maps = similarity.T.reshape(k_final, feature_h, feature_w)
        return activation_maps.unsqueeze(0)


def automatic_region_label(
    activation_map: np.ndarray,
    detection_a: Detection,
    detection_b: Detection,
    pair_union: np.ndarray,
) -> str:
    support = box_mask(pair_union, (activation_map.shape[1], activation_map.shape[0]))
    normalized = normalize_map(activation_map, support)
    total = float((normalized * support).sum()) + 1e-8

    mass_a = float((normalized * box_mask(detection_a.box_xyxy, (activation_map.shape[1], activation_map.shape[0]))).sum()) / total
    mass_b = float((normalized * box_mask(detection_b.box_xyxy, (activation_map.shape[1], activation_map.shape[0]))).sum()) / total
    context_mass = max(0.0, 1.0 - min(1.0, mass_a + mass_b))

    if mass_a >= 0.25 and mass_b >= 0.25:
        return "shared pair region"
    if mass_a >= max(0.20, mass_b):
        return f"{detection_a.class_name}-dominant region"
    if mass_b >= max(0.20, mass_a):
        return f"{detection_b.class_name}-dominant region"
    if context_mass >= 0.45:
        return "shared context"
    return "mixed relational region"
