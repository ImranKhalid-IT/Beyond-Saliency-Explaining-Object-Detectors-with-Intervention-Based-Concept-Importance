from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import torch

@dataclass(frozen=True)
class PairSpec:
    object_a: str
    object_b: str
    max_gap_fraction: float = 0.35
    max_union_fraction: float = 0.92
    max_examples: int = 1


@dataclass
class LetterboxMeta:
    original_size: Tuple[int, int]      # width, height
    input_size: Tuple[int, int]         # width, height
    resized_size: Tuple[int, int]       # width, height
    ratio: float
    left: int
    top: int


@dataclass
class Detection:
    box_xyxy: np.ndarray
    score: float
    label_idx: int
    class_name: str


@dataclass
class GroundTruthPair:
    image_id: int
    file_name: str
    width: int
    height: int
    object_a: str
    object_b: str
    box_a: np.ndarray
    box_b: np.ndarray
    quality_score: float


@dataclass
class ConceptResult:
    concept_index: int
    effect_score: float
    original_score_a: float
    original_score_b: float
    post_score_a: float
    post_score_b: float
    mask_fraction: float
    auto_region_label: str
    activation_map: np.ndarray
    intervention_mask: np.ndarray


@dataclass
class CraftConcept:
    concept_index: int
    importance: float
    activation_mass: float
    activation_map: np.ndarray


@dataclass
class UnifiedBaselineResult:
    maps: Dict[str, np.ndarray]
    metadata: Dict[str, Any]
    runtimes: Dict[str, float]
