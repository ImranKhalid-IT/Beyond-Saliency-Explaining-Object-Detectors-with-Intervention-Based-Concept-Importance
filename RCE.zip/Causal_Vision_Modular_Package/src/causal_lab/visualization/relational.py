from __future__ import annotations

from pathlib import Path
import math
from typing import Dict, List, Sequence, Tuple
import cv2
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont
from ..config import SAVE_PDF, SHOW_TOP_CONCEPTS
from ..schemas import ConceptResult, Detection
from ..utils.geometry import box_mask, normalize_map

def draw_labelled_box(
    image_rgb: np.ndarray,
    detection: Detection,
    color: Tuple[int, int, int],
) -> None:
    x1, y1, x2, y2 = np.round(detection.box_xyxy).astype(int)
    cv2.rectangle(image_rgb, (x1, y1), (x2, y2), color, 3)
    label = f"{detection.class_name} {detection.score:.2f}"
    font = cv2.FONT_HERSHEY_SIMPLEX
    scale, thickness = 0.65, 2
    (text_w, text_h), baseline = cv2.getTextSize(
        label, font, scale, thickness
    )
    label_top = max(0, y1 - text_h - baseline - 8)
    cv2.rectangle(
        image_rgb,
        (x1, label_top),
        (x1 + text_w + 8, label_top + text_h + baseline + 8),
        color,
        -1,
    )
    cv2.putText(
        image_rgb,
        label,
        (x1 + 4, label_top + text_h + 3),
        font,
        scale,
        (0, 0, 0),
        thickness,
        cv2.LINE_AA,
    )


def make_union_overlay(
    image_rgb: np.ndarray, pair_union: np.ndarray
) -> np.ndarray:
    result = image_rgb.copy()
    overlay = result.copy()
    x1, y1, x2, y2 = np.round(pair_union).astype(int)
    cv2.rectangle(overlay, (x1, y1), (x2, y2), (255, 0, 255), -1)
    result = cv2.addWeighted(overlay, 0.32, result, 0.68, 0.0)
    cv2.rectangle(result, (x1, y1), (x2, y2), (255, 0, 255), 4)
    return result


def combined_top_concept_heatmap(
    concept_results: Sequence[ConceptResult],
    pair_union: np.ndarray,
    image_size: Tuple[int, int],
    top_n: int = 3,
) -> np.ndarray:
    width, height = image_size
    support = box_mask(pair_union, image_size)
    ranked = sorted(
        concept_results, key=lambda result: result.effect_score, reverse=True
    )
    selected = ranked[: max(1, min(top_n, len(ranked)))]

    positive_weights = np.array(
        [max(0.0, result.effect_score) for result in selected],
        dtype=np.float32,
    )
    if float(positive_weights.sum()) <= 1e-8:
        positive_weights = np.ones(len(selected), dtype=np.float32)
    positive_weights /= positive_weights.sum()

    heatmap = np.zeros((height, width), dtype=np.float32)
    for weight, result in zip(positive_weights, selected):
        heatmap += weight * result.activation_map

    heatmap *= support
    heatmap = normalize_map(heatmap, support)
    sigma = max(2.0, min(width, height) / 120.0)
    heatmap = cv2.GaussianBlur(heatmap, (0, 0), sigmaX=sigma, sigmaY=sigma)
    return normalize_map(heatmap, support)


def overlay_heatmap(image_rgb: np.ndarray, heatmap: np.ndarray) -> np.ndarray:
    colored_bgr = cv2.applyColorMap(
        np.uint8(np.clip(heatmap, 0.0, 1.0) * 255),
        cv2.COLORMAP_JET,
    )
    colored_rgb = cv2.cvtColor(colored_bgr, cv2.COLOR_BGR2RGB)
    nonzero = heatmap[heatmap > 0]
    if nonzero.size == 0:
        return image_rgb.copy()

    threshold = float(np.percentile(nonzero, 60))
    alpha = np.clip((heatmap - threshold) / (1.0 - threshold + 1e-8), 0.0, 1.0)
    alpha = (0.78 * alpha)[..., None]
    darkened = (image_rgb.astype(np.float32) * 0.48)
    composed = darkened * (1.0 - alpha) + colored_rgb.astype(np.float32) * alpha
    return np.uint8(np.clip(composed, 0, 255))


def create_dashboard(
    image: Image.Image,
    image_id: int,
    detection_a: Detection,
    detection_b: Detection,
    pair_union: np.ndarray,
    concept_results: Sequence[ConceptResult],
    output_stem: Path,
) -> Path:
    image_rgb = np.asarray(image.convert("RGB"))
    boxed = image_rgb.copy()
    draw_labelled_box(boxed, detection_a, (0, 255, 255))
    draw_labelled_box(boxed, detection_b, (255, 255, 0))
    union_view = make_union_overlay(image_rgb, pair_union)

    heatmap = combined_top_concept_heatmap(
        concept_results, pair_union, image.size, top_n=3
    )
    heatmap_view = overlay_heatmap(image_rgb, heatmap)

    ranked = sorted(
        concept_results, key=lambda result: result.effect_score, reverse=True
    )
    displayed = ranked[: min(SHOW_TOP_CONCEPTS, len(ranked))]
    labels = [
        f"C{result.concept_index + 1}: {result.auto_region_label}"
        for result in displayed
    ]
    scores = [result.effect_score for result in displayed]

    fig, axes = plt.subplots(2, 2, figsize=(13.2, 10.5))
    fig.suptitle(
        f"Qualitative RCE Example: {detection_a.class_name} + "
        f"{detection_b.class_name}  |  COCO image {image_id}",
        fontsize=16,
        fontweight="bold",
    )

    axes[0, 0].imshow(boxed)
    axes[0, 0].set_title("1. Interacting Objects Detected", fontweight="bold")
    axes[0, 0].axis("off")

    axes[0, 1].imshow(union_view)
    axes[0, 1].set_title("2. Relational Analysis Region", fontweight="bold")
    axes[0, 1].axis("off")

    axes[1, 0].imshow(heatmap_view)
    axes[1, 0].set_title("3. Top-Ranked RCE Concept Overlay", fontweight="bold")
    axes[1, 0].axis("off")

    y_positions = np.arange(len(labels))
    bar_colors = ["coral" if value >= 0 else "lightgray" for value in scores]
    axes[1, 1].barh(
        y_positions,
        scores,
        color=bar_colors,
        edgecolor="black",
        linewidth=0.8,
    )
    axes[1, 1].set_yticks(y_positions)
    axes[1, 1].set_yticklabels(labels, fontsize=9)
    axes[1, 1].invert_yaxis()
    axes[1, 1].axvline(0.0, linewidth=1.0, color="black")
    axes[1, 1].set_xlabel(r"Concept-Effect Score $CE_k$")
    axes[1, 1].set_title("4. Interventional Concept Ranking", fontweight="bold")
    axes[1, 1].grid(axis="x", linestyle=":", alpha=0.35)

    for y_value, score in zip(y_positions, scores):
        offset = 0.008 * max(1e-3, max(abs(np.asarray(scores))))
        horizontal = score + offset if score >= 0 else score - offset
        alignment = "left" if score >= 0 else "right"
        axes[1, 1].text(
            horizontal,
            y_value,
            f"{score:.3f}",
            va="center",
            ha=alignment,
            fontsize=8,
        )

    fig.text(
        0.5,
        0.012,
        "Concept descriptions are automatically derived from activation "
        "overlap and are not semantic labels generated by RCE.",
        ha="center",
        fontsize=9,
    )
    plt.tight_layout(rect=[0.0, 0.035, 1.0, 0.95])

    png_path = output_stem.with_suffix(".png")
    fig.savefig(png_path, dpi=300, bbox_inches="tight")
    if SAVE_PDF:
        fig.savefig(output_stem.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)
    return png_path


def create_contact_sheet(
    dashboard_paths: Sequence[Path],
    output_path: Path,
    columns: int = 2,
    panel_width: int = 1700,
    margin: int = 30,
) -> Path:
    if not dashboard_paths:
        raise ValueError("No dashboard paths were supplied.")

    panels: List[Image.Image] = []
    for dashboard_path in dashboard_paths:
        panel = Image.open(dashboard_path).convert("RGB")
        scale = panel_width / float(panel.width)
        panel = panel.resize(
            (panel_width, int(round(panel.height * scale))),
            Image.Resampling.LANCZOS,
        )
        panels.append(panel)

    rows = math.ceil(len(panels) / columns)
    row_heights: List[int] = []
    for row in range(rows):
        row_panels = panels[row * columns : (row + 1) * columns]
        row_heights.append(max(panel.height for panel in row_panels))

    sheet_width = columns * panel_width + (columns + 1) * margin
    sheet_height = sum(row_heights) + (rows + 1) * margin
    sheet = Image.new("RGB", (sheet_width, sheet_height), "white")

    y = margin
    for row in range(rows):
        x = margin
        row_panels = panels[row * columns : (row + 1) * columns]
        for panel in row_panels:
            sheet.paste(panel, (x, y))
            x += panel_width + margin
        y += row_heights[row] + margin

    sheet.save(output_path, dpi=(300, 300))
    return output_path
