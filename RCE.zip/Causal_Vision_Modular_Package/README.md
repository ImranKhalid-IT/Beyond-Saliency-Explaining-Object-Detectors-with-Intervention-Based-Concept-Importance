# Causal Vision Modular Package

This repository is intentionally separated into data, model, concepts, interventions, baselines, visualization, and pipeline layers. It does not include the private runtime token, COCO data, model cache, or generated outputs.

## Authorized setup

1. Keep the owner token outside GitHub.
2. Run `scripts/bootstrap.ps1` on Windows PowerShell.
3. Set the token only in the local shell:
   `$env:CAUSAL_LAB_ACCESS_TOKEN="..."`
4. Prepare COCO under `data/coco` or configure `COCO_ROOT`.
5. Run one of the scripts in `scripts/`.

The package is a research-code deterrence layout, not an unbreakable DRM system. Anyone who can modify Python source can remove a software-only gate.
