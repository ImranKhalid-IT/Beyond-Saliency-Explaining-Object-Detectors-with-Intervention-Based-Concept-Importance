# Owner notes

Do not commit the private access token, trained weights, COCO data, `.env`, or result archives. Use a private repository and branch protection. For stronger source protection, distribute a container or compiled service rather than editable Python source.
