# Architecture map

- `data/`: COCO retrieval and pair selection
- `models/`: YOLOv5 loading, detection, and feature hooks
- `concepts/`: K-means and NMF concept extraction
- `interventions/`: relational counterfactual intervention
- `baselines/`: D-RISE, gradient adapters, CRAFT, unified comparison
- `visualization/`: dashboards and contact sheets
- `pipelines/`: complete experiment orchestration
- `single_image/`: separate single-image causal demonstration
- `archive/original_sources/`: immutable uploaded originals
